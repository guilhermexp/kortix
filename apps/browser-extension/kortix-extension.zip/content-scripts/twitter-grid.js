var twitterGrid=(function(){"use strict";function st(f){return f}const D={matches:["*://x.com/*","*://twitter.com/*"],world:"MAIN",main(){const f="3.0.0",v={version:f,autoStart:!1},b="twc-grid-container",u="twc-grid-item",T=460,I=new Set;let M=!1,R=!1,S=null,q=!1;const H=`
/* ==========================================================
   Twitter Card Grid – CSS Completo
   ========================================================== */

/* ── 0. Body: esconder scrollbar nativa ───────────────────── */
body[data-twc-started][data-twc-grid-mode] {
	scrollbar-width: none !important;
}
body[data-twc-started][data-twc-grid-mode]::-webkit-scrollbar {
	display: none !important;
}

/* ── 1. Esconder sidebar, header, drawers ─────────────────── */
body[data-twc-started][data-twc-grid-mode] header[role="banner"],
body[data-twc-started][data-twc-grid-mode] [data-testid="sidebarColumn"],
body[data-twc-started][data-twc-grid-mode] [data-testid="DMDrawer"],
body[data-twc-started][data-twc-grid-mode] [data-testid="GrokDrawer"] {
	display: none !important;
}

/* ── 2. Esconder main original (precisa existir pro virtualizer) */
body[data-twc-started][data-twc-grid-mode] main {
	opacity: 0 !important;
	pointer-events: none !important;
	z-index: -1 !important;
	position: relative !important;
}

/* ── 3. Masonry container (CSS columns) ───────────────────── */
body[data-twc-started][data-twc-grid-mode] .${b} {
	display: block !important;
	column-count: 3;
	column-gap: 16px;
	position: fixed;
	top: 56px;
	left: 0;
	right: 0;
	bottom: 0;
	overflow-y: auto;
	overflow-x: hidden;
	padding: 16px;
	background-color: rgb(0, 0, 0);
	z-index: 2147483646;
}

/* ── 4. Grid item ─────────────────────────────────────────── */
body[data-twc-started][data-twc-grid-mode] .${u} {
	min-width: 0;
	break-inside: avoid;
	margin-bottom: 16px;
	display: block;
}

/* ── 5. Card do tweet ─────────────────────────────────────── */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] {
	border: 1px solid rgba(255, 255, 255, 0.12);
	border-radius: 16px;
	overflow: hidden;
	background-color: rgb(0, 0, 0);
	width: 100% !important;
	max-width: none !important;
	margin: 0 !important;
	contain: inline-size;
}

/* ── 6. Wildcard: limitar largura de TODOS os filhos ──────── */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] * {
	max-width: 100% !important;
	box-sizing: border-box;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #1: Divs com height FIXO inline
   Twitter coloca style="width: 502px; height: 510px;" num
   container ancestral da mídia. max-width:100% reduz o width,
   mas o HEIGHT permanece fixo → distorção.
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] div[style*="height"] {
	height: auto !important;
}
/* Exceções: preservar height fixa nos avatares */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] [data-testid*="UserAvatar"] div[style*="height"],
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] [data-testid="Tweet-User-Avatar"] div[style*="height"] {
	height: revert !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #2: Imagens e vídeos responsivos
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweetPhoto"] img,
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="videoPlayer"] video,
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="videoPlayer"] img,
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="videoComponent"] video {
	width: 100% !important;
	height: auto !important;
	max-height: ${T}px !important;
	object-fit: cover !important;
}

/* ── 8. Container de vídeo ────────────────────────────────── */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="videoPlayer"],
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="videoComponent"] {
	border-radius: 12px;
	max-height: ${T}px !important;
	overflow: hidden !important;
	width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #3: NÃO sobrescrever padding-bottom original.
   Preservar aspect ratio nativo (16:9, 9:16, 1:1, etc.).
   ══════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #4: Container de mídia com width inline fixa
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] div[style*="width"] {
	width: 100% !important;
}
/* Exceções: avatares */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] [data-testid*="UserAvatar"] div[style*="width"],
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] [data-testid="Tweet-User-Avatar"] div[style*="width"] {
	width: revert !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #5: tweetPhoto container
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweetPhoto"] {
	width: 100% !important;
	height: auto !important;
	max-height: ${T}px;
	overflow: hidden;
	border-radius: 12px;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #6: Card wrapper (link previews: GitHub, etc)
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="card.wrapper"] {
	width: 100% !important;
	max-width: 100% !important;
	overflow: hidden;
	border-radius: 12px;
	border: 1px solid rgba(255, 255, 255, 0.12);
}
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="card.layoutLarge.media"],
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="card.layoutSmall.media"] {
	width: 100% !important;
	overflow: hidden;
}
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="card.wrapper"] img {
	width: 100% !important;
	height: auto !important;
	max-height: 300px;
	object-fit: cover !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #7: Grid de múltiplas imagens
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] [aria-label] div[style*="grid"] {
	width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #8: Links <a> com width fixa
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweet"] a {
	max-width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #9: Video element overflow (+3px bug do Twitter)
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} video {
	width: 100% !important;
	max-width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #11: Thumbnail <img> sobre vídeo – position absolute
   Quando tweetPhoto contém um <video>, o Twitter sobrepõe uma
   <img> (thumbnail) com position:absolute. Ao clonar, o clone
   perde o position:absolute e os 2 filhos empilham, dobrando
   a altura. :has(video) garante que só se aplica quando há vídeo.
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweetPhoto"]:has(video) > img {
	position: absolute !important;
	top: 0 !important;
	left: 0 !important;
	width: 100% !important;
	height: 100% !important;
	z-index: 1 !important;
	object-fit: cover !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #10: Texto longo – truncar com line-clamp
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${u} [data-testid="tweetText"] {
	overflow: hidden;
	display: -webkit-box;
	-webkit-line-clamp: 8;
	-webkit-box-orient: vertical;
	word-break: break-word;
}

/* ── 11. Botão start (UI da extensão) ─────────────────────── */
.twc-start {
	width: 40px;
	height: 40px;
	border: none;
	border-radius: 10px;
	position: fixed;
	bottom: 16px;
	left: 16px;
	cursor: pointer;
	transition: opacity 0.2s, transform 0.2s;
	background: rgb(0, 0, 0);
	color: rgb(255, 255, 255);
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 0;
	z-index: 2147483647;
	opacity: 0.7;
	border: 1px solid rgba(255, 255, 255, 0.2);
}

.twc-start:hover {
	opacity: 1;
	transform: scale(1.1);
}

.twc-txt-btn {
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
	background: none;
	border: none;
	color: rgb(139, 152, 165);
	transition: color 0.2s;
	cursor: pointer;
	font-size: 13px;
	padding: 4px 8px;
	z-index: 2147483647;
}

.twc-txt-btn:hover {
	color: rgb(255, 255, 255);
}

body[data-twc-started] .twc-start {
	display: none;
}

/* ── 12. Responsivo ───────────────────────────────────────── */
@media (max-width: 900px) {
	body[data-twc-started][data-twc-grid-mode] .${b} {
		column-count: 2;
	}
}

@media (max-width: 560px) {
	body[data-twc-started][data-twc-grid-mode] .${b} {
		column-count: 1;
		padding: 10px;
		column-gap: 10px;
	}
	body[data-twc-started][data-twc-grid-mode] .${u} {
		margin-bottom: 10px;
	}
}
`;function j(t){let e=document.querySelector(".twc-style");e||(e=document.createElement("style"),e.classList.add("twc-style"),document.head.appendChild(e)),e.textContent=t}function V(){let t={};try{t=JSON.parse(localStorage.getItem("twc-settings")||"{}")}catch{localStorage.removeItem("twc-settings")}typeof t.autoStart=="boolean"&&(v.autoStart=t.autoStart)}function N(){v.version=f,localStorage.setItem("twc-settings",JSON.stringify(v))}function k(){return"twcStarted"in document.body.dataset}function O(){return document.querySelector('[aria-label="Timeline: Your Home Timeline"]')||document.querySelector('[aria-label="Home timeline"]')||document.querySelector('[data-testid="primaryColumn"] section > h1 + div[aria-label] > div')||document.querySelector('[data-testid="primaryColumn"] section [aria-label]')}function U(t){const e=t.querySelector('a[href*="/status/"]');if(!e)return null;const s=e.href.match(/\/status\/(\d+)/);return s?s[1]:null}function W(t){const e=O();return e?Array.from(e.querySelectorAll("[data-testid='tweet']:not([data-twc-cloned])")).filter(c=>{const n=c.closest("[data-testid='cellInnerDiv']");return!(!n||n.querySelector("div[role='progressbar']"))}).slice(0,t):[]}const z=["[data-testid='tweetPhoto']","[data-testid='card.wrapper']","[data-testid='videoPlayer']","[data-testid='videoComponent']"];function F(t){return z.some(e=>t.closest(e)!==null)}function X(t,e){for(const r of z){const p=Array.from(t.querySelectorAll(r)),d=Array.from(e.querySelectorAll(r));for(let i=0;i<p.length&&i<d.length;i++){const o=Array.from(p[i].querySelectorAll("div")),w=Array.from(d[i].querySelectorAll("div"));for(let a=0;a<o.length&&a<w.length;a++){const h=window.getComputedStyle(w[a]),y=h.backgroundImage;y&&y!=="none"&&(o[a].style.backgroundImage=y,o[a].style.backgroundSize=h.backgroundSize||"cover",o[a].style.backgroundPosition=h.backgroundPosition||"center",o[a].style.backgroundRepeat="no-repeat");const A=h.backgroundColor;(A==="rgb(32, 35, 39)"||A==="rgb(21, 24, 28)"||A==="rgb(39, 44, 48)")&&(o[a].style.backgroundColor="transparent")}}}const s=t.querySelectorAll("img"),l=e.querySelectorAll("img");s.forEach((r,p)=>{const d=l[p];r.removeAttribute("loading"),r.setAttribute("loading","eager"),d?.currentSrc&&(r.src=d.currentSrc),d?.srcset&&(r.srcset=d.srcset),r.style.setProperty("opacity","1","important"),F(r)&&(r.style.setProperty("position","relative","important"),r.style.setProperty("z-index","auto","important"),r.style.setProperty("width","100%","important"),r.style.setProperty("height","100%","important"),r.style.setProperty("object-fit","cover","important"))});const c=t.querySelectorAll('[data-testid="Tweet-User-Avatar"] div'),n=e.querySelectorAll('[data-testid="Tweet-User-Avatar"] div');for(let r=0;r<c.length&&r<n.length;r++){const p=window.getComputedStyle(n[r]),d=p.backgroundImage;d&&d!=="none"&&(c[r].style.backgroundImage=d,c[r].style.backgroundSize=p.backgroundSize||"cover",c[r].style.backgroundPosition=p.backgroundPosition||"center")}const m=t.querySelectorAll("video"),g=e.querySelectorAll("video");m.forEach((r,p)=>{const i=g[p]?.poster||r.getAttribute("poster");i&&(r.poster=i),r.style.setProperty("object-fit","cover","important"),r.preload="none";try{r.pause()}catch{}if(i){const o=r.closest('[data-testid="tweetPhoto"]')||r.closest('[data-testid="videoPlayer"]');if(o&&!o.querySelector("img.twc-poster")){const w=document.createElement("img");w.src=i,w.classList.add("twc-poster"),w.style.cssText="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:1;",o.prepend(w)}}}),t.querySelectorAll('[data-testid="tweetPhoto"]').forEach(r=>{const p=r.querySelector("video"),d=r.querySelectorAll("img");if(!Array.from(d).some(o=>o.naturalWidth>0||o.currentSrc)&&p?.poster&&!r.querySelector("img.twc-poster")){const o=document.createElement("img");o.src=p.poster,o.classList.add("twc-poster"),o.style.cssText="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:1;",r.prepend(o)}})}const C=new Map;let x=null;function J(){if(x)return;x=new MutationObserver(()=>{if(C.size!==0)for(const[e,{clone:s,original:l}]of C){const c=l.querySelectorAll('[data-testid="tweetPhoto"]'),n=s.querySelectorAll('[data-testid="tweetPhoto"]');let m=!1;c.forEach((g,r)=>{const p=n[r];if(!p)return;const d=g.querySelectorAll("img"),i=p.querySelectorAll("img");d.forEach((a,h)=>{if(!a.currentSrc)return;const y=i[h];y&&!y.currentSrc&&(y.src=a.currentSrc,a.srcset&&(y.srcset=a.srcset),y.style.setProperty("opacity","1","important"),m=!0)});const o=Array.from(g.querySelectorAll("div")),w=Array.from(p.querySelectorAll("div"));for(let a=0;a<o.length&&a<w.length;a++){const h=window.getComputedStyle(o[a]),y=h.backgroundImage;y&&y!=="none"&&!w[a].style.backgroundImage&&(w[a].style.backgroundImage=y,w[a].style.backgroundSize=h.backgroundSize||"cover",w[a].style.backgroundPosition=h.backgroundPosition||"center",w[a].style.backgroundRepeat="no-repeat",m=!0)}}),m&&C.delete(e)}});const t=O();t&&x.observe(t,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["src","style"]})}function Y(){x&&(x.disconnect(),x=null,C.clear())}function Z(t){t.querySelectorAll(`.${u}`).forEach(s=>{const l=s.querySelector('[data-testid="tweet"]');if(!l)return;const c=l.querySelector('[data-testid="tweetText"]'),n=l.querySelector('[role="group"]');if(!c||!n)return;const m=c.getBoundingClientRect().bottom,g=n.getBoundingClientRect().top;if(g-m<60)return;let p=!1;if(l.querySelectorAll("img, video").forEach(i=>{const o=i.getBoundingClientRect();o.top>=m-10&&o.bottom<=g+10&&o.height>30&&(p=!0)}),p)return;const d=[];l.querySelectorAll("div, a").forEach(i=>{const o=i.getBoundingClientRect();if(o.top>=m-5&&o.bottom<=g+5&&o.height>50){let w=0,a=i;for(;a&&a!==l;)w++,a=a.parentElement;d.push({el:i,depth:w})}}),d.length>0&&(d.sort((i,o)=>i.depth-o.depth),d[0].el.style.display="none")})}function K(){const t=document.querySelector('[data-testid="videoPlayer"]');if(!t)return;const e=Object.keys(t).find(n=>n.startsWith("__reactFiber"));if(!e)return;const s=document.querySelector("main"),l=document.querySelector(`.${b}`);if(!s||!l)return;const c={};s.querySelectorAll("article").forEach(n=>{const m=n.querySelector('[data-testid="videoPlayer"]');if(!m)return;const d=(n.querySelector('a[href*="/status/"] time')?.parentElement?.href??"").match(/status\/(\d+)/);if(!d)return;let i=m[e],o=0;for(;i&&o<25;){if(i.memoizedProps?.source?.variants){const w=i.memoizedProps.source.variants;let a=null;for(const h of w){if((h.content_type||h.contentType)!=="video/mp4")continue;const A=h.bitrate??0;(!a||A>(a.bitrate??0)&&A<=5e6)&&(a=h)}if(!a)for(const h of w)(h.content_type||h.contentType)==="video/mp4"&&(!a||(h.bitrate??0)>(a.bitrate??0))&&(a=h);a&&(c[d[1]]={url:a.url||a.src||"",bitrate:a.bitrate??0});break}i=i.return,o++}}),l.querySelectorAll(`.${u}`).forEach(n=>{const m=n.querySelector("video");if(!m||m.dataset.twcPlayable)return;const p=(n.querySelector('a[href*="/status/"] time')?.parentElement?.href??"").match(/status\/(\d+)/);if(!p||!c[p[1]])return;const d=n.querySelector('[data-testid="tweetPhoto"]');if(!d)return;const i=document.createElement("video");i.src=c[p[1]].url,i.controls=!0,i.playsInline=!0,i.preload="metadata",i.poster=m.poster||"",i.dataset.twcPlayable="true",i.style.cssText="width:100%; height:auto; max-height:500px; object-fit:contain; border-radius:12px; background:#000;",d.innerHTML="",d.style.display="block",d.appendChild(i)})}function Q(){const t=document.querySelector(`.${b}`);if(!t)return;function e(){const m=document.cookie.split(";").map(g=>g.trim()).find(g=>g.startsWith("ct0="));return m?m.split("=")[1]:null}const s="AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";async function l(m,g){const r=e();return r?(await fetch(g==="remove"?"https://x.com/i/api/1.1/bookmark/entries/remove.json":"https://x.com/i/api/1.1/bookmark/entries/add.json",{method:"POST",headers:{authorization:"Bearer "+decodeURIComponent(s),"x-csrf-token":r,"x-twitter-auth-type":"OAuth2Session","x-twitter-active-user":"yes","content-type":"application/x-www-form-urlencoded"},body:"tweet_id="+m,credentials:"include"})).status===200:!1}const c='<g><path d="M4 4.5C4 3.12 5.119 2 6.5 2h11C18.881 2 20 3.12 20 4.5v18.44l-8-5.71-8 5.71V4.5z"></path></g>',n='<g><path d="M4 4.5C4 3.12 5.119 2 6.5 2h11C18.881 2 20 3.12 20 4.5v18.44l-8-5.71-8 5.71V4.5zM6.5 4c-.276 0-.5.22-.5.5v14.56l6-4.29 6 4.29V4.5c0-.28-.224-.5-.5-.5h-11z"></path></g>';t.querySelectorAll(`.${u}`).forEach(m=>{const g=m.querySelector("article");if(!g)return;const d=(g.querySelector('a[href*="/status/"] time')?.parentElement?.href??"").match(/status\/(\d+)/);if(!d)return;const i=d[1],o=g.querySelector('[data-testid="removeBookmark"], [data-testid="bookmark"]');!o||o.dataset.twcBookmarkProxy||(o.dataset.twcBookmarkProxy="true",o.style.cursor="pointer",o.addEventListener("click",async w=>{w.preventDefault(),w.stopPropagation(),w.stopImmediatePropagation();const a=o.getAttribute("data-testid")==="removeBookmark";if(await l(i,a?"remove":"add")){const y=o.querySelector("svg");a?(o.setAttribute("data-testid","bookmark"),o.setAttribute("aria-label","Bookmark"),y&&(y.innerHTML=n,y.style.color="rgb(113, 118, 123)")):(o.setAttribute("data-testid","removeBookmark"),o.setAttribute("aria-label","Bookmarked"),y&&(y.innerHTML=c,y.style.color="rgb(29, 155, 240)"))}},!0))})}function P(t=12){if(!q){q=!0;try{const e=document.querySelector(`.${b}`);if(!e)return;const s=W(t);for(const l of s){const c=U(l);if(c&&I.has(c)){l.setAttribute("data-twc-cloned","true");continue}l.setAttribute("data-twc-cloned","true"),c&&I.add(c);const n=l.cloneNode(!0);if(n.style.removeProperty("position"),n.style.removeProperty("top"),n.style.removeProperty("left"),n.style.removeProperty("transform"),n.style.removeProperty("translate"),n.style.removeProperty("rotate"),n.style.removeProperty("width"),X(n,l),c){const g=n.querySelectorAll('[data-testid="tweetPhoto"]'),r=l.querySelectorAll('[data-testid="tweetPhoto"]');Array.from(g).some(d=>{const i=d.querySelectorAll("img:not(.twc-poster)");return Array.from(i).some(o=>!o.currentSrc&&o.naturalWidth===0)})&&r.length>0&&C.set(c,{clone:n,original:l})}const m=document.createElement("article");m.classList.add(u),m.appendChild(n),e.appendChild(m)}requestAnimationFrame(()=>{Z(e),K(),Q()})}finally{q=!1}}}function tt(){for(let s=0;s<5;s++)window.setTimeout(()=>{window.scrollBy(0,600)},s*100)}function et(){if(S)return;const t=O();t&&(S=new MutationObserver(()=>{!k()||q||requestAnimationFrame(()=>{P(8)})}),S.observe(t,{childList:!0,subtree:!0}))}function ot(){S&&(S.disconnect(),S=null)}function rt(){if(R)return;const t=document.querySelector(`.${b}`);if(!t)return;R=!0;let e=!1;t.addEventListener("scroll",()=>{e||!(t.scrollTop+t.clientHeight>=t.scrollHeight-400)||(e=!0,tt(),window.setTimeout(()=>{P(20),window.setTimeout(()=>{P(20),e=!1},1500)},1e3))})}function at(){if(document.querySelector(`.${b}`))return;const t=document.createElement("div");t.classList.add(b),document.body.appendChild(t),rt()}function L(){k()||(document.body.dataset.twcStarted="true",document.body.dataset.twcGridMode="true",at(),P(30),et(),J())}function B(t=!1){ot(),Y(),R=!1,delete document.body.dataset.twcStarted,delete document.body.dataset.twcGridMode;const e=document.querySelector(`.${b}`);e&&e.remove(),I.clear(),t&&window.location.reload()}function G(){return k()?(B(!0),!1):($(),L(),!0)}function it(){const t=document.createElement("button");t.classList.add("twc-start"),t.innerHTML='<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="1" width="7" height="7" rx="1.5"/><rect x="12" y="1" width="7" height="7" rx="1.5"/><rect x="1" y="12" width="7" height="7" rx="1.5"/><rect x="12" y="12" width="7" height="7" rx="1.5"/></svg>',t.title="X Grid",t.onclick=L,document.body.appendChild(t);const e=document.createElement("button");e.classList.add("twc-txt-btn"),e.innerText="X",e.style.position="fixed",e.style.top="16px",e.style.right="16px",e.style.cursor="pointer",e.onclick=()=>B(!0),document.body.appendChild(e);const s=document.createElement("details"),l=document.createElement("summary");l.innerText="Settings",l.style.cursor="pointer",s.appendChild(l),s.classList.add("twc-txt-btn"),s.style.position="fixed",s.style.top="16px",s.style.left="16px";const c=document.createElement("label");c.innerText="Autostart: ";const n=document.createElement("input");n.type="checkbox",n.checked=v.autoStart,n.oninput=()=>{v.autoStart=n.checked,N()},c.appendChild(n),s.appendChild(c);const m=document.createElement("p");m.innerHTML=`X Grid v${f}<br>Single view mode (grid)`,s.appendChild(m),document.body.appendChild(s)}function nt(){V(),j(H),it(),v.autoStart&&L()}function $(){M||(M=!0,nt())}document.addEventListener("kortix-grid-request",t=>{const e=t.detail??{},s=e.requestId,l=e.command;let c=k();l==="toggle"?c=G():l==="state"&&(c=k()),document.dispatchEvent(new CustomEvent("kortix-grid-response",{detail:{requestId:s,active:c}}))}),document.addEventListener("kortix-toggle-grid",()=>{G()});function dt(){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>$()):$()}dt()}};function ct(){}function E(f,...v){}const _={debug:(...f)=>E(console.debug,...f),log:(...f)=>E(console.log,...f),warn:(...f)=>E(console.warn,...f),error:(...f)=>E(console.error,...f)};return(async()=>{try{return await D.main()}catch(f){throw _.error('The content script "twitter-grid" crashed on startup!',f),f}})()})();
twitterGrid;