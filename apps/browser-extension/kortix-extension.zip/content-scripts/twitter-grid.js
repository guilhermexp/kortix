var twitterGrid=(function(){"use strict";function et(i){return i}const _={matches:["*://x.com/*","*://twitter.com/*"],world:"MAIN",main(){const i="3.0.0",w={version:i,autoStart:!1},m="twc-grid-container",c="twc-grid-item",P=460,T=new Set;let q=!1,y=-1,I=!1,g=null,x=!1;const R=`
/* Body scroll stays enabled — Twitter's virtualizer needs real window scroll
   to trigger IntersectionObserver on its sentinel and load more tweets.
   Hide the scrollbar since the grid overlay covers the viewport. */
body[data-twc-started][data-twc-grid-mode] {
	scrollbar-width: none !important;
}

body[data-twc-started][data-twc-grid-mode]::-webkit-scrollbar {
	display: none !important;
}

body[data-twc-started][data-twc-grid-mode] header[role="banner"],
body[data-twc-started][data-twc-grid-mode] [data-testid="sidebarColumn"],
body[data-twc-started][data-twc-grid-mode] [data-testid="DMDrawer"],
body[data-twc-started][data-twc-grid-mode] [data-testid="GrokDrawer"] {
	display: none !important;
}

/* main stays in document flow (NOT position:fixed) so it contributes to
   document.scrollHeight. The virtualizer uses window scroll position to
   decide which items to render and when to fetch more. */
body[data-twc-started][data-twc-grid-mode] main {
	opacity: 0 !important;
	pointer-events: none !important;
	z-index: -1 !important;
	position: relative !important;
}

body[data-twc-started][data-twc-grid-mode] .${m} {
	display: grid !important;
	position: fixed;
	top: 56px;
	left: 0;
	right: 0;
	bottom: 0;
	overflow-y: auto;
	overflow-x: hidden;
	padding: 16px;
	gap: 16px;
	grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
	align-content: start;
	background: #000;
	z-index: 2147483646;
}

body[data-twc-started][data-twc-grid-mode] .${c} {
	min-width: 0;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="tweet"] {
	width: 100% !important;
	max-width: none !important;
	margin: 0 !important;
	border: 1px solid rgba(255, 255, 255, 0.12);
	border-radius: 16px;
	overflow: hidden;
	background: #000;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="tweet"] * {
	max-width: 100%;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="tweetPhoto"] img,
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"] video,
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"] img,
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoComponent"] video {
	width: 100% !important;
	height: auto !important;
	max-height: ${P}px !important;
	object-fit: cover !important;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"],
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoComponent"] {
	max-height: ${P}px !important;
	overflow: hidden !important;
	border-radius: 12px;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"] div[style*="padding-bottom"] {
	padding-bottom: 56.25% !important;
}

.twc-start {
	width: 40px;
	height: 40px;
	border: none;
	border-radius: 10px;
	position: fixed;
	bottom: 16px;
	left: 16px;
	cursor: pointer;
	transition: opacity 0.2s, transform 0.2s;
	background: #000;
	color: #fff;
	display: flex;
	align-items: center;
	justify-content: center;
	opacity: 0.7;
	z-index: 2147483647;
}

.twc-start:hover {
	opacity: 1;
	transform: scale(1.05);
}

.twc-txt-btn {
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
	background: none;
	border: none;
	color: #8b98a5;
	transition: color 0.2s;
	z-index: 2147483647;
}

.twc-txt-btn:hover {
	color: #fff;
}

body[data-twc-started] .twc-start {
	display: none;
}

@media (max-width: 900px) {
	body[data-twc-started][data-twc-grid-mode] .${m} {
		grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
	}
}

@media (max-width: 560px) {
	body[data-twc-started][data-twc-grid-mode] .${m} {
		grid-template-columns: 1fr;
		padding: 10px;
		gap: 10px;
	}
}
`;function H(t){let e=document.querySelector(".twc-style");e||(e=document.createElement("style"),e.classList.add("twc-style"),document.head.appendChild(e)),e.textContent=t}function O(){let t={};try{t=JSON.parse(localStorage.getItem("twc-settings")||"{}")}catch{localStorage.removeItem("twc-settings")}typeof t.autoStart=="boolean"&&(w.autoStart=t.autoStart)}function N(){w.version=i,localStorage.setItem("twc-settings",JSON.stringify(w))}function b(){return"twcStarted"in document.body.dataset}function $(){return document.querySelector('[aria-label="Timeline: Your Home Timeline"]')||document.querySelector('[aria-label="Home timeline"]')||document.querySelector('[data-testid="primaryColumn"] section > h1 + div[aria-label] > div')||document.querySelector('[data-testid="primaryColumn"] section [aria-label]')}function B(t){const e=t.querySelector('a[href*="/status/"]');if(!e)return null;const r=e.href.match(/\/status\/(\d+)/);return r?r[1]:null}function X(t){const e=$();return e?Array.from(e.querySelectorAll("[data-testid='tweet']:not([data-twc-cloned])")).filter(a=>{const n=a.closest("[data-testid='cellInnerDiv']");return!(!n||n.querySelector("div[role='progressbar']"))}).slice(0,t):[]}const G=["[data-testid='tweetPhoto']","[data-testid='card.wrapper']","[data-testid='videoPlayer']","[data-testid='videoComponent']"];function j(t){return G.some(e=>t.closest(e)!==null)}function V(t,e){for(const o of G){const l=Array.from(t.querySelectorAll(o)),s=Array.from(e.querySelectorAll(o));for(let v=0;v<l.length&&v<s.length;v++){const f=Array.from(l[v].querySelectorAll("div")),M=Array.from(s[v].querySelectorAll("div"));for(let u=0;u<f.length&&u<M.length;u++){const C=window.getComputedStyle(M[u]),k=C.backgroundImage;k&&k!=="none"&&(f[u].style.backgroundImage=k,f[u].style.backgroundSize=C.backgroundSize||"cover",f[u].style.backgroundPosition=C.backgroundPosition||"center",f[u].style.backgroundRepeat="no-repeat");const E=C.backgroundColor;(E==="rgb(32, 35, 39)"||E==="rgb(21, 24, 28)"||E==="rgb(39, 44, 48)")&&(f[u].style.backgroundColor="transparent")}}}const r=t.querySelectorAll("img"),d=e.querySelectorAll("img");r.forEach((o,l)=>{const s=d[l];o.removeAttribute("loading"),o.setAttribute("loading","eager"),s?.currentSrc&&(o.src=s.currentSrc),s?.srcset&&(o.srcset=s.srcset),o.style.setProperty("opacity","1","important"),j(o)&&(o.style.setProperty("position","relative","important"),o.style.setProperty("z-index","auto","important"),o.style.setProperty("width","100%","important"),o.style.setProperty("height","100%","important"),o.style.setProperty("object-fit","cover","important"))});const a=t.querySelectorAll('[data-testid="Tweet-User-Avatar"] div'),n=e.querySelectorAll('[data-testid="Tweet-User-Avatar"] div');for(let o=0;o<a.length&&o<n.length;o++){const l=window.getComputedStyle(n[o]),s=l.backgroundImage;s&&s!=="none"&&(a[o].style.backgroundImage=s,a[o].style.backgroundSize=l.backgroundSize||"cover",a[o].style.backgroundPosition=l.backgroundPosition||"center")}const p=t.querySelectorAll("video"),tt=e.querySelectorAll("video");p.forEach((o,l)=>{const s=tt[l];s?.poster&&(o.poster=s.poster),o.style.setProperty("object-fit","cover","important"),o.preload="none";try{o.pause()}catch{}})}function h(t=12){if(!x){x=!0;try{const e=document.querySelector(`.${m}`);if(!e)return;const r=X(t);for(const d of r){const a=B(d);if(a&&T.has(a)){d.setAttribute("data-twc-cloned","true");continue}d.setAttribute("data-twc-cloned","true"),a&&T.add(a);const n=d.cloneNode(!0);n.style.removeProperty("position"),n.style.removeProperty("top"),n.style.removeProperty("left"),n.style.removeProperty("transform"),n.style.removeProperty("translate"),n.style.removeProperty("rotate"),n.style.removeProperty("width"),V(n,d);const p=document.createElement("article");p.classList.add(c),p.appendChild(n),e.appendChild(p)}}finally{x=!1}}}function U(){for(let r=0;r<5;r++)window.setTimeout(()=>{window.scrollBy(0,600)},r*100)}function W(){if(g)return;const t=$();t&&(g=new MutationObserver(()=>{!b()||x||requestAnimationFrame(()=>{h(8)})}),g.observe(t,{childList:!0,subtree:!0}))}function F(){g&&(g.disconnect(),g=null)}function J(){if(I)return;const t=document.querySelector(`.${m}`);if(!t)return;I=!0;let e=!1;t.addEventListener("scroll",()=>{e||!(t.scrollTop+t.clientHeight>=t.scrollHeight-1200)||(e=!0,U(),window.setTimeout(()=>{h(20),window.setTimeout(()=>{h(20),e=!1},1e3)},800))})}function Y(){if(document.querySelector(`.${m}`))return;const t=document.createElement("div");t.classList.add(m),document.body.appendChild(t),J()}function A(){b()||(document.body.dataset.twcStarted="true",document.body.dataset.twcGridMode="true",Y(),h(30),W(),y!==-1&&window.clearInterval(y),y=window.setInterval(()=>{h(8)},2e3))}function L(t=!1){y!==-1&&(window.clearInterval(y),y=-1),F(),I=!1,delete document.body.dataset.twcStarted,delete document.body.dataset.twcGridMode;const e=document.querySelector(`.${m}`);e&&e.remove(),T.clear(),t&&window.location.reload()}function D(){return b()?(L(!0),!1):(Z(),A(),!0)}function K(){const t=document.createElement("button");t.classList.add("twc-start"),t.innerHTML='<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="1" width="7" height="7" rx="1.5"/><rect x="12" y="1" width="7" height="7" rx="1.5"/><rect x="1" y="12" width="7" height="7" rx="1.5"/><rect x="12" y="12" width="7" height="7" rx="1.5"/></svg>',t.title="X Grid",t.onclick=A,document.body.appendChild(t);const e=document.createElement("button");e.classList.add("twc-txt-btn"),e.innerText="X",e.style.position="fixed",e.style.top="16px",e.style.right="16px",e.style.cursor="pointer",e.onclick=()=>L(!0),document.body.appendChild(e);const r=document.createElement("details"),d=document.createElement("summary");d.innerText="Settings",d.style.cursor="pointer",r.appendChild(d),r.classList.add("twc-txt-btn"),r.style.position="fixed",r.style.top="16px",r.style.left="16px";const a=document.createElement("label");a.innerText="Autostart: ";const n=document.createElement("input");n.type="checkbox",n.checked=w.autoStart,n.oninput=()=>{w.autoStart=n.checked,N()},a.appendChild(n),r.appendChild(a);const p=document.createElement("p");p.innerHTML=`X Grid v${i}<br>Single view mode (grid)`,r.appendChild(p),document.body.appendChild(r)}function Q(){O(),H(R),K(),w.autoStart&&A()}function Z(){q||(q=!0,Q())}document.addEventListener("kortix-grid-request",t=>{const e=t.detail??{},r=e.requestId,d=e.command;let a=b();d==="toggle"?a=D():d==="state"&&(a=b()),document.dispatchEvent(new CustomEvent("kortix-grid-response",{detail:{requestId:r,active:a}}))}),document.addEventListener("kortix-toggle-grid",()=>{D()})}};function ot(){}function S(i,...w){}const z={debug:(...i)=>S(console.debug,...i),log:(...i)=>S(console.log,...i),warn:(...i)=>S(console.warn,...i),error:(...i)=>S(console.error,...i)};return(async()=>{try{return await _.main()}catch(i){throw z.error('The content script "twitter-grid" crashed on startup!',i),i}})()})();
twitterGrid;