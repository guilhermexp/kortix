var twitterGrid=(function(){"use strict";function F(n){return n}const q={matches:["*://x.com/*","*://twitter.com/*"],world:"MAIN",main(){const n="3.0.0",m={version:n,autoStart:!1},l="twc-grid-container",c="twc-grid-item",C=460,S=new Set;let I=!1,w=-1,x=!1,p=null,v=!1;const P=`
/* Body scroll stays enabled — Twitter's virtualizer needs real window scroll
   to trigger IntersectionObserver on its sentinel and load more tweets.
   Hide the scrollbar since the grid overlay covers the viewport. */
body[data-twc-started][data-twc-grid-mode] {
	scrollbar-width: none !important;
}

body[data-twc-started][data-twc-grid-mode]::-webkit-scrollbar {
	display: none !important;
}

body[data-twc-started][data-twc-grid-mode] header[role="banner"],
body[data-twc-started][data-twc-grid-mode] [data-testid="sidebarColumn"],
body[data-twc-started][data-twc-grid-mode] [data-testid="DMDrawer"],
body[data-twc-started][data-twc-grid-mode] [data-testid="GrokDrawer"] {
	display: none !important;
}

/* main stays in document flow (NOT position:fixed) so it contributes to
   document.scrollHeight. The virtualizer uses window scroll position to
   decide which items to render and when to fetch more. */
body[data-twc-started][data-twc-grid-mode] main {
	opacity: 0 !important;
	pointer-events: none !important;
	z-index: -1 !important;
	position: relative !important;
}

body[data-twc-started][data-twc-grid-mode] .${l} {
	display: grid !important;
	position: fixed;
	top: 56px;
	left: 0;
	right: 0;
	bottom: 0;
	overflow-y: auto;
	overflow-x: hidden;
	padding: 16px;
	gap: 16px;
	grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
	align-content: start;
	background: #000;
	z-index: 2147483646;
}

body[data-twc-started][data-twc-grid-mode] .${c} {
	min-width: 0;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="tweet"] {
	width: 100% !important;
	max-width: none !important;
	margin: 0 !important;
	border: 1px solid rgba(255, 255, 255, 0.12);
	border-radius: 16px;
	overflow: hidden;
	background: #000;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="tweet"] * {
	max-width: 100%;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="tweetPhoto"] img,
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"] video,
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"] img,
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoComponent"] video {
	width: 100% !important;
	height: auto !important;
	max-height: ${C}px !important;
	object-fit: cover !important;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"],
body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoComponent"] {
	max-height: ${C}px !important;
	overflow: hidden !important;
	border-radius: 12px;
}

body[data-twc-started][data-twc-grid-mode] .${c} [data-testid="videoPlayer"] div[style*="padding-bottom"] {
	padding-bottom: 56.25% !important;
}

.twc-start {
	width: 40px;
	height: 40px;
	border: none;
	border-radius: 10px;
	position: fixed;
	bottom: 16px;
	left: 16px;
	cursor: pointer;
	transition: opacity 0.2s, transform 0.2s;
	background: #000;
	color: #fff;
	display: flex;
	align-items: center;
	justify-content: center;
	opacity: 0.7;
	z-index: 2147483647;
}

.twc-start:hover {
	opacity: 1;
	transform: scale(1.05);
}

.twc-txt-btn {
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
	background: none;
	border: none;
	color: #8b98a5;
	transition: color 0.2s;
	z-index: 2147483647;
}

.twc-txt-btn:hover {
	color: #fff;
}

body[data-twc-started] .twc-start {
	display: none;
}

@media (max-width: 900px) {
	body[data-twc-started][data-twc-grid-mode] .${l} {
		grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
	}
}

@media (max-width: 560px) {
	body[data-twc-started][data-twc-grid-mode] .${l} {
		grid-template-columns: 1fr;
		padding: 10px;
		gap: 10px;
	}
}
`;function G(t){let e=document.querySelector(".twc-style");e||(e=document.createElement("style"),e.classList.add("twc-style"),document.head.appendChild(e)),e.textContent=t}function L(){let t={};try{t=JSON.parse(localStorage.getItem("twc-settings")||"{}")}catch{localStorage.removeItem("twc-settings")}typeof t.autoStart=="boolean"&&(m.autoStart=t.autoStart)}function D(){m.version=n,localStorage.setItem("twc-settings",JSON.stringify(m))}function y(){return"twcStarted"in document.body.dataset}function E(){return document.querySelector('[aria-label="Timeline: Your Home Timeline"]')||document.querySelector('[aria-label="Home timeline"]')||document.querySelector('[data-testid="primaryColumn"] section > h1 + div[aria-label] > div')||document.querySelector('[data-testid="primaryColumn"] section [aria-label]')}function M(t){const e=t.querySelector('a[href*="/status/"]');if(!e)return null;const r=e.href.match(/\/status\/(\d+)/);return r?r[1]:null}function _(t){const e=E();return e?Array.from(e.querySelectorAll("[data-testid='tweet']:not([data-twc-cloned])")).filter(i=>{const o=i.closest("[data-testid='cellInnerDiv']");return!(!o||o.querySelector("div[role='progressbar']"))}).slice(0,t):[]}function H(t,e){const r=t.querySelectorAll("img"),d=e.querySelectorAll("img");r.forEach((a,b)=>{const s=d[b];if(a.removeAttribute("loading"),a.setAttribute("loading","eager"),s?.currentSrc&&s.currentSrc!==a.src&&(a.src=s.currentSrc),s?.srcset&&(a.srcset=s.srcset),!a.src||a.src==="about:blank"){const f=a.getAttribute("data-src")||a.dataset.src;f&&(a.src=f)}a.style.removeProperty("visibility"),a.style.removeProperty("opacity")});const i=t.querySelectorAll("div[style*='background-image']"),o=e.querySelectorAll("div[style*='background-image']");i.forEach((a,b)=>{const s=o[b];if(s){const f=window.getComputedStyle(s).backgroundImage;f&&f!=="none"&&(a.style.backgroundImage=f)}});const u=t.querySelectorAll("video"),j=e.querySelectorAll("video");u.forEach((a,b)=>{const s=j[b];s?.poster&&(a.poster=s.poster);try{a.pause()}catch{}})}function g(t=12){if(!v){v=!0;try{const e=document.querySelector(`.${l}`);if(!e)return;const r=_(t);for(const d of r){const i=M(d);if(i&&S.has(i)){d.setAttribute("data-twc-cloned","true");continue}d.setAttribute("data-twc-cloned","true"),i&&S.add(i);const o=d.cloneNode(!0);o.style.removeProperty("position"),o.style.removeProperty("top"),o.style.removeProperty("left"),o.style.removeProperty("transform"),o.style.removeProperty("translate"),o.style.removeProperty("rotate"),o.style.removeProperty("width"),H(o,d);const u=document.createElement("article");u.classList.add(c),u.appendChild(o),e.appendChild(u)}}finally{v=!1}}}function N(){for(let r=0;r<5;r++)window.setTimeout(()=>{window.scrollBy(0,600)},r*100)}function O(){if(p)return;const t=E();t&&(p=new MutationObserver(()=>{!y()||v||requestAnimationFrame(()=>{g(8)})}),p.observe(t,{childList:!0,subtree:!0}))}function R(){p&&(p.disconnect(),p=null)}function z(){if(x)return;const t=document.querySelector(`.${l}`);if(!t)return;x=!0;let e=!1;t.addEventListener("scroll",()=>{e||!(t.scrollTop+t.clientHeight>=t.scrollHeight-1200)||(e=!0,N(),window.setTimeout(()=>{g(20),window.setTimeout(()=>{g(20),e=!1},1e3)},800))})}function B(){if(document.querySelector(`.${l}`))return;const t=document.createElement("div");t.classList.add(l),document.body.appendChild(t),z()}function T(){y()||(document.body.dataset.twcStarted="true",document.body.dataset.twcGridMode="true",B(),g(30),O(),w!==-1&&window.clearInterval(w),w=window.setInterval(()=>{g(8)},2e3))}function k(t=!1){w!==-1&&(window.clearInterval(w),w=-1),R(),x=!1,delete document.body.dataset.twcStarted,delete document.body.dataset.twcGridMode;const e=document.querySelector(`.${l}`);e&&e.remove(),S.clear(),t&&window.location.reload()}function A(){return y()?(k(!0),!1):(W(),T(),!0)}function X(){const t=document.createElement("button");t.classList.add("twc-start"),t.innerHTML='<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="1" width="7" height="7" rx="1.5"/><rect x="12" y="1" width="7" height="7" rx="1.5"/><rect x="1" y="12" width="7" height="7" rx="1.5"/><rect x="12" y="12" width="7" height="7" rx="1.5"/></svg>',t.title="X Grid",t.onclick=T,document.body.appendChild(t);const e=document.createElement("button");e.classList.add("twc-txt-btn"),e.innerText="X",e.style.position="fixed",e.style.top="16px",e.style.right="16px",e.style.cursor="pointer",e.onclick=()=>k(!0),document.body.appendChild(e);const r=document.createElement("details"),d=document.createElement("summary");d.innerText="Settings",d.style.cursor="pointer",r.appendChild(d),r.classList.add("twc-txt-btn"),r.style.position="fixed",r.style.top="16px",r.style.left="16px";const i=document.createElement("label");i.innerText="Autostart: ";const o=document.createElement("input");o.type="checkbox",o.checked=m.autoStart,o.oninput=()=>{m.autoStart=o.checked,D()},i.appendChild(o),r.appendChild(i);const u=document.createElement("p");u.innerHTML=`X Grid v${n}<br>Single view mode (grid)`,r.appendChild(u),document.body.appendChild(r)}function V(){L(),G(P),X(),m.autoStart&&T()}function W(){I||(I=!0,V())}document.addEventListener("kortix-grid-request",t=>{const e=t.detail??{},r=e.requestId,d=e.command;let i=y();d==="toggle"?i=A():d==="state"&&(i=y()),document.dispatchEvent(new CustomEvent("kortix-grid-response",{detail:{requestId:r,active:i}}))}),document.addEventListener("kortix-toggle-grid",()=>{A()})}};function J(){}function h(n,...m){}const $={debug:(...n)=>h(console.debug,...n),log:(...n)=>h(console.log,...n),warn:(...n)=>h(console.warn,...n),error:(...n)=>h(console.error,...n)};return(async()=>{try{return await q.main()}catch(n){throw $.error('The content script "twitter-grid" crashed on startup!',n),n}})()})();
twitterGrid;