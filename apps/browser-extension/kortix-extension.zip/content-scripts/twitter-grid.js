var twitterGrid=(function(){"use strict";function nt(p){return p}const _={matches:["*://x.com/*","*://twitter.com/*"],world:"MAIN",main(){const p="3.0.0",v={version:p,autoStart:!1},f="twc-grid-container",i="twc-grid-item",I=460,P=new Set;let G=!1,S=-1,R=!1,x=null,q=!1;const N=`
/* ==========================================================
   Twitter Card Grid – CSS Completo
   ========================================================== */

/* ── 0. Body: esconder scrollbar nativa ───────────────────── */
body[data-twc-started][data-twc-grid-mode] {
	scrollbar-width: none !important;
}
body[data-twc-started][data-twc-grid-mode]::-webkit-scrollbar {
	display: none !important;
}

/* ── 1. Esconder sidebar, header, drawers ─────────────────── */
body[data-twc-started][data-twc-grid-mode] header[role="banner"],
body[data-twc-started][data-twc-grid-mode] [data-testid="sidebarColumn"],
body[data-twc-started][data-twc-grid-mode] [data-testid="DMDrawer"],
body[data-twc-started][data-twc-grid-mode] [data-testid="GrokDrawer"] {
	display: none !important;
}

/* ── 2. Esconder main original (precisa existir pro virtualizer) */
body[data-twc-started][data-twc-grid-mode] main {
	opacity: 0 !important;
	pointer-events: none !important;
	z-index: -1 !important;
	position: relative !important;
}

/* ── 3. Masonry container (CSS columns) ───────────────────── */
body[data-twc-started][data-twc-grid-mode] .${f} {
	display: block !important;
	column-count: 3;
	column-gap: 16px;
	position: fixed;
	top: 56px;
	left: 0;
	right: 0;
	bottom: 0;
	overflow-y: auto;
	overflow-x: hidden;
	padding: 16px;
	background-color: rgb(0, 0, 0);
	z-index: 2147483646;
}

/* ── 4. Grid item ─────────────────────────────────────────── */
body[data-twc-started][data-twc-grid-mode] .${i} {
	min-width: 0;
	break-inside: avoid;
	margin-bottom: 16px;
	display: block;
}

/* ── 5. Card do tweet ─────────────────────────────────────── */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] {
	border: 1px solid rgba(255, 255, 255, 0.12);
	border-radius: 16px;
	overflow: hidden;
	background-color: rgb(0, 0, 0);
	width: 100% !important;
	max-width: none !important;
	margin: 0 !important;
	contain: inline-size;
}

/* ── 6. Wildcard: limitar largura de TODOS os filhos ──────── */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] * {
	max-width: 100% !important;
	box-sizing: border-box;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #1: Divs com height FIXO inline
   Twitter coloca style="width: 502px; height: 510px;" num
   container ancestral da mídia. max-width:100% reduz o width,
   mas o HEIGHT permanece fixo → distorção.
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] div[style*="height"] {
	height: auto !important;
}
/* Exceções: preservar height fixa nos avatares */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] [data-testid*="UserAvatar"] div[style*="height"],
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] [data-testid="Tweet-User-Avatar"] div[style*="height"] {
	height: revert !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #2: Imagens e vídeos responsivos
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweetPhoto"] img,
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="videoPlayer"] video,
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="videoPlayer"] img,
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="videoComponent"] video {
	width: 100% !important;
	height: auto !important;
	max-height: ${I}px !important;
	object-fit: cover !important;
}

/* ── 8. Container de vídeo ────────────────────────────────── */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="videoPlayer"],
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="videoComponent"] {
	border-radius: 12px;
	max-height: ${I}px !important;
	overflow: hidden !important;
	width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #3: NÃO sobrescrever padding-bottom original.
   Preservar aspect ratio nativo (16:9, 9:16, 1:1, etc.).
   ══════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #4: Container de mídia com width inline fixa
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] div[style*="width"] {
	width: 100% !important;
}
/* Exceções: avatares */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] [data-testid*="UserAvatar"] div[style*="width"],
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] [data-testid="Tweet-User-Avatar"] div[style*="width"] {
	width: revert !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #5: tweetPhoto container
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweetPhoto"] {
	width: 100% !important;
	height: auto !important;
	max-height: ${I}px;
	overflow: hidden;
	border-radius: 12px;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #6: Card wrapper (link previews: GitHub, etc)
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="card.wrapper"] {
	width: 100% !important;
	max-width: 100% !important;
	overflow: hidden;
	border-radius: 12px;
	border: 1px solid rgba(255, 255, 255, 0.12);
}
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="card.layoutLarge.media"],
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="card.layoutSmall.media"] {
	width: 100% !important;
	overflow: hidden;
}
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="card.wrapper"] img {
	width: 100% !important;
	height: auto !important;
	max-height: 300px;
	object-fit: cover !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #7: Grid de múltiplas imagens
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] [aria-label] div[style*="grid"] {
	width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #8: Links <a> com width fixa
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweet"] a {
	max-width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #9: Video element overflow (+3px bug do Twitter)
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} video {
	width: 100% !important;
	max-width: 100% !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #11: Thumbnail <img> sobre vídeo – position absolute
   Quando tweetPhoto contém um <video>, o Twitter sobrepõe uma
   <img> (thumbnail) com position:absolute. Ao clonar, o clone
   perde o position:absolute e os 2 filhos empilham, dobrando
   a altura. :has(video) garante que só se aplica quando há vídeo.
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweetPhoto"]:has(video) > img {
	position: absolute !important;
	top: 0 !important;
	left: 0 !important;
	width: 100% !important;
	height: 100% !important;
	z-index: 1 !important;
	object-fit: cover !important;
}

/* ══════════════════════════════════════════════════════════════
   CORREÇÃO #10: Texto longo – truncar com line-clamp
   ══════════════════════════════════════════════════════════════ */
body[data-twc-started][data-twc-grid-mode] .${i} [data-testid="tweetText"] {
	overflow: hidden;
	display: -webkit-box;
	-webkit-line-clamp: 8;
	-webkit-box-orient: vertical;
	word-break: break-word;
}

/* ── 11. Botão start (UI da extensão) ─────────────────────── */
.twc-start {
	width: 40px;
	height: 40px;
	border: none;
	border-radius: 10px;
	position: fixed;
	bottom: 80px;
	right: 16px;
	cursor: pointer;
	transition: opacity 0.2s, transform 0.2s;
	background: rgb(0, 0, 0);
	color: rgb(255, 255, 255);
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 0;
	z-index: 2147483647;
	opacity: 0.7;
	border: 1px solid rgba(255, 255, 255, 0.2);
}

.twc-start:hover {
	opacity: 1;
	transform: scale(1.1);
}

.twc-txt-btn {
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
	background: none;
	border: none;
	color: rgb(139, 152, 165);
	transition: color 0.2s;
	cursor: pointer;
	font-size: 13px;
	padding: 4px 8px;
	z-index: 2147483647;
}

.twc-txt-btn:hover {
	color: rgb(255, 255, 255);
}

body[data-twc-started] .twc-start {
	display: none;
}

/* ── 12. Responsivo ───────────────────────────────────────── */
@media (max-width: 900px) {
	body[data-twc-started][data-twc-grid-mode] .${f} {
		column-count: 2;
	}
}

@media (max-width: 560px) {
	body[data-twc-started][data-twc-grid-mode] .${f} {
		column-count: 1;
		padding: 10px;
		column-gap: 10px;
	}
	body[data-twc-started][data-twc-grid-mode] .${i} {
		margin-bottom: 10px;
	}
}
`;function U(t){let e=document.querySelector(".twc-style");e||(e=document.createElement("style"),e.classList.add("twc-style"),document.head.appendChild(e)),e.textContent=t}function j(){let t={};try{t=JSON.parse(localStorage.getItem("twc-settings")||"{}")}catch{localStorage.removeItem("twc-settings")}typeof t.autoStart=="boolean"&&(v.autoStart=t.autoStart)}function V(){v.version=p,localStorage.setItem("twc-settings",JSON.stringify(v))}function A(){return"twcStarted"in document.body.dataset}function O(){return document.querySelector('[aria-label="Timeline: Your Home Timeline"]')||document.querySelector('[aria-label="Home timeline"]')||document.querySelector('[data-testid="primaryColumn"] section > h1 + div[aria-label] > div')||document.querySelector('[data-testid="primaryColumn"] section [aria-label]')}function W(t){const e=t.querySelector('a[href*="/status/"]');if(!e)return null;const n=e.href.match(/\/status\/(\d+)/);return n?n[1]:null}function X(t){const e=O();return e?Array.from(e.querySelectorAll("[data-testid='tweet']:not([data-twc-cloned])")).filter(c=>{const d=c.closest("[data-testid='cellInnerDiv']");return!(!d||d.querySelector("div[role='progressbar']"))}).slice(0,t):[]}const z=["[data-testid='tweetPhoto']","[data-testid='card.wrapper']","[data-testid='videoPlayer']","[data-testid='videoComponent']"];function F(t){return z.some(e=>t.closest(e)!==null)}function J(t,e){for(const o of z){const m=Array.from(t.querySelectorAll(o)),l=Array.from(e.querySelectorAll(o));for(let u=0;u<m.length&&u<l.length;u++){const r=Array.from(m[u].querySelectorAll("div")),w=Array.from(l[u].querySelectorAll("div"));for(let a=0;a<r.length&&a<w.length;a++){const b=window.getComputedStyle(w[a]),y=b.backgroundImage;y&&y!=="none"&&(r[a].style.backgroundImage=y,r[a].style.backgroundSize=b.backgroundSize||"cover",r[a].style.backgroundPosition=b.backgroundPosition||"center",r[a].style.backgroundRepeat="no-repeat");const L=b.backgroundColor;(L==="rgb(32, 35, 39)"||L==="rgb(21, 24, 28)"||L==="rgb(39, 44, 48)")&&(r[a].style.backgroundColor="transparent")}}}const n=t.querySelectorAll("img"),s=e.querySelectorAll("img");n.forEach((o,m)=>{const l=s[m];o.removeAttribute("loading"),o.setAttribute("loading","eager"),l?.currentSrc&&(o.src=l.currentSrc),l?.srcset&&(o.srcset=l.srcset),o.style.setProperty("opacity","1","important"),F(o)&&(o.style.setProperty("position","relative","important"),o.style.setProperty("z-index","auto","important"),o.style.setProperty("width","100%","important"),o.style.setProperty("height","100%","important"),o.style.setProperty("object-fit","cover","important"))});const c=t.querySelectorAll('[data-testid="Tweet-User-Avatar"] div'),d=e.querySelectorAll('[data-testid="Tweet-User-Avatar"] div');for(let o=0;o<c.length&&o<d.length;o++){const m=window.getComputedStyle(d[o]),l=m.backgroundImage;l&&l!=="none"&&(c[o].style.backgroundImage=l,c[o].style.backgroundSize=m.backgroundSize||"cover",c[o].style.backgroundPosition=m.backgroundPosition||"center")}const g=t.querySelectorAll("video"),h=e.querySelectorAll("video");g.forEach((o,m)=>{const u=h[m]?.poster||o.getAttribute("poster");u&&(o.poster=u),o.style.setProperty("object-fit","cover","important"),o.preload="none";try{o.pause()}catch{}if(u){const r=o.closest('[data-testid="tweetPhoto"]')||o.closest('[data-testid="videoPlayer"]');if(r&&!r.querySelector("img.twc-poster")){const w=document.createElement("img");w.src=u,w.classList.add("twc-poster"),w.style.cssText="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:1;",r.prepend(w)}}}),t.querySelectorAll('[data-testid="tweetPhoto"]').forEach(o=>{const m=o.querySelector("video"),l=o.querySelectorAll("img");if(!Array.from(l).some(r=>r.naturalWidth>0||r.currentSrc)&&m?.poster&&!o.querySelector("img.twc-poster")){const r=document.createElement("img");r.src=m.poster,r.classList.add("twc-poster"),r.style.cssText="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:1;",o.prepend(r)}})}const E=new Map;let C=null;function Q(){if(C)return;C=new MutationObserver(()=>{if(E.size!==0)for(const[e,{clone:n,original:s}]of E){const c=s.querySelectorAll('[data-testid="tweetPhoto"]'),d=n.querySelectorAll('[data-testid="tweetPhoto"]');let g=!1;c.forEach((h,o)=>{const m=d[o];if(!m)return;const l=h.querySelectorAll("img"),u=m.querySelectorAll("img");l.forEach((a,b)=>{if(!a.currentSrc)return;const y=u[b];y&&!y.currentSrc&&(y.src=a.currentSrc,a.srcset&&(y.srcset=a.srcset),y.style.setProperty("opacity","1","important"),g=!0)});const r=Array.from(h.querySelectorAll("div")),w=Array.from(m.querySelectorAll("div"));for(let a=0;a<r.length&&a<w.length;a++){const b=window.getComputedStyle(r[a]),y=b.backgroundImage;y&&y!=="none"&&!w[a].style.backgroundImage&&(w[a].style.backgroundImage=y,w[a].style.backgroundSize=b.backgroundSize||"cover",w[a].style.backgroundPosition=b.backgroundPosition||"center",w[a].style.backgroundRepeat="no-repeat",g=!0)}}),g&&E.delete(e)}});const t=O();t&&C.observe(t,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["src","style"]})}function Y(){C&&(C.disconnect(),C=null,E.clear())}function K(t){t.querySelectorAll(`.${i}`).forEach(n=>{const s=n.querySelector('[data-testid="tweet"]');if(!s)return;const c=s.querySelector('[data-testid="tweetText"]'),d=s.querySelector('[role="group"]');if(!c||!d)return;const g=c.getBoundingClientRect().bottom,h=d.getBoundingClientRect().top;if(h-g<60)return;let m=!1;if(s.querySelectorAll("img, video").forEach(u=>{const r=u.getBoundingClientRect();r.top>=g-10&&r.bottom<=h+10&&r.height>30&&(m=!0)}),m)return;const l=[];s.querySelectorAll("div, a").forEach(u=>{const r=u.getBoundingClientRect();if(r.top>=g-5&&r.bottom<=h+5&&r.height>50){let w=0,a=u;for(;a&&a!==s;)w++,a=a.parentElement;l.push({el:u,depth:w})}}),l.length>0&&(l.sort((u,r)=>u.depth-r.depth),l[0].el.style.display="none")})}function k(t=12){if(!q){q=!0;try{const e=document.querySelector(`.${f}`);if(!e)return;const n=X(t);for(const s of n){const c=W(s);if(c&&P.has(c)){s.setAttribute("data-twc-cloned","true");continue}s.setAttribute("data-twc-cloned","true"),c&&P.add(c);const d=s.cloneNode(!0);if(d.style.removeProperty("position"),d.style.removeProperty("top"),d.style.removeProperty("left"),d.style.removeProperty("transform"),d.style.removeProperty("translate"),d.style.removeProperty("rotate"),d.style.removeProperty("width"),J(d,s),c){const h=d.querySelectorAll('[data-testid="tweetPhoto"]'),o=s.querySelectorAll('[data-testid="tweetPhoto"]');Array.from(h).some(l=>{const u=l.querySelectorAll("img:not(.twc-poster)");return Array.from(u).some(r=>!r.currentSrc&&r.naturalWidth===0)})&&o.length>0&&E.set(c,{clone:d,original:s})}const g=document.createElement("article");g.classList.add(i),g.appendChild(d),e.appendChild(g)}requestAnimationFrame(()=>{K(e)})}finally{q=!1}}}function Z(){for(let n=0;n<5;n++)window.setTimeout(()=>{window.scrollBy(0,600)},n*100)}function tt(){if(x)return;const t=O();t&&(x=new MutationObserver(()=>{!A()||q||requestAnimationFrame(()=>{k(8)})}),x.observe(t,{childList:!0,subtree:!0}))}function et(){x&&(x.disconnect(),x=null)}function ot(){if(R)return;const t=document.querySelector(`.${f}`);if(!t)return;R=!0;let e=!1;t.addEventListener("scroll",()=>{e||!(t.scrollTop+t.clientHeight>=t.scrollHeight-1200)||(e=!0,Z(),window.setTimeout(()=>{k(20),window.setTimeout(()=>{k(20),e=!1},1e3)},800))})}function rt(){if(document.querySelector(`.${f}`))return;const t=document.createElement("div");t.classList.add(f),document.body.appendChild(t),ot()}function $(){A()||(document.body.dataset.twcStarted="true",document.body.dataset.twcGridMode="true",rt(),k(30),tt(),Q(),S!==-1&&window.clearInterval(S),S=window.setInterval(()=>{k(8)},2e3))}function D(t=!1){S!==-1&&(window.clearInterval(S),S=-1),et(),Y(),R=!1,delete document.body.dataset.twcStarted,delete document.body.dataset.twcGridMode;const e=document.querySelector(`.${f}`);e&&e.remove(),P.clear(),t&&window.location.reload()}function B(){return A()?(D(!0),!1):(M(),$(),!0)}function at(){const t=document.createElement("button");t.classList.add("twc-start"),t.innerHTML='<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="1" width="7" height="7" rx="1.5"/><rect x="12" y="1" width="7" height="7" rx="1.5"/><rect x="1" y="12" width="7" height="7" rx="1.5"/><rect x="12" y="12" width="7" height="7" rx="1.5"/></svg>',t.title="X Grid",t.onclick=$,document.body.appendChild(t);const e=document.createElement("button");e.classList.add("twc-txt-btn"),e.innerText="X",e.style.position="fixed",e.style.top="16px",e.style.right="16px",e.style.cursor="pointer",e.onclick=()=>D(!0),document.body.appendChild(e);const n=document.createElement("details"),s=document.createElement("summary");s.innerText="Settings",s.style.cursor="pointer",n.appendChild(s),n.classList.add("twc-txt-btn"),n.style.position="fixed",n.style.top="16px",n.style.left="16px";const c=document.createElement("label");c.innerText="Autostart: ";const d=document.createElement("input");d.type="checkbox",d.checked=v.autoStart,d.oninput=()=>{v.autoStart=d.checked,V()},c.appendChild(d),n.appendChild(c);const g=document.createElement("p");g.innerHTML=`X Grid v${p}<br>Single view mode (grid)`,n.appendChild(g),document.body.appendChild(n)}function it(){j(),U(N),at(),v.autoStart&&$()}function M(){G||(G=!0,it())}document.addEventListener("kortix-grid-request",t=>{const e=t.detail??{},n=e.requestId,s=e.command;let c=A();s==="toggle"?c=B():s==="state"&&(c=A()),document.dispatchEvent(new CustomEvent("kortix-grid-response",{detail:{requestId:n,active:c}}))}),document.addEventListener("kortix-toggle-grid",()=>{B()});function dt(){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>M()):M()}dt()}};function st(){}function T(p,...v){}const H={debug:(...p)=>T(console.debug,...p),log:(...p)=>T(console.log,...p),warn:(...p)=>T(console.warn,...p),error:(...p)=>T(console.error,...p)};return(async()=>{try{return await _.main()}catch(p){throw H.error('The content script "twitter-grid" crashed on startup!',p),p}})()})();
twitterGrid;