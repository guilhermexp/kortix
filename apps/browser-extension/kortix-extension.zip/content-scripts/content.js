var content=(function(){"use strict";function _e(n){return n}const p=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,ce="https://kortix.claudedokploy.com",b={BEARER_TOKEN:"bearer-token",REFRESH_TOKEN:"refresh-token",USER_DATA:"user-data",AUTO_SEARCH_ENABLED:"sm-auto-search-enabled"},T={TWITTER_IMPORT_BUTTON:"sm-twitter-import-button",KORTIX_TOAST:"sm-toast",CHATGPT_INPUT_BAR_ELEMENT:"sm-chatgpt-input-bar-element",CLAUDE_INPUT_BAR_ELEMENT:"sm-claude-input-bar-element",T3_INPUT_BAR_ELEMENT:"sm-t3-input-bar-element"},w={BUTTON_SHOW_DELAY:2e3,TOAST_DURATION:3e3,RATE_LIMIT_BASE_WAIT:6e4,PAGINATION_DELAY:1e3,AUTO_SEARCH_DEBOUNCE_DELAY:1500,OBSERVER_THROTTLE_DELAY:300,ROUTE_CHECK_INTERVAL:2e3,API_REQUEST_TIMEOUT:1e4},E={TWITTER:["x.com","twitter.com"],CHATGPT:["chatgpt.com","chat.openai.com"],CLAUDE:["claude.ai"],T3:["t3.chat"],KORTIX:["localhost",new URL(ce).hostname]},g={SAVE_MEMORY:"sm-save-memory",SHOW_TOAST:"sm-show-toast",BATCH_IMPORT_ALL:"sm-batch-import-all",IMPORT_UPDATE:"sm-import-update",IMPORT_DONE:"sm-import-done",GET_RELATED_MEMORIES:"sm-get-related-memories",CAPTURE_PROMPT:"sm-capture-prompt",TOGGLE_X_GRID:"sm-toggle-x-grid",GET_X_GRID_STATE:"sm-get-x-grid-state"};function de(n){const e=document.createElement("div");if(e.id=T.KORTIX_TOAST,e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2147483647;
    background: #0a0a0a;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 9999px;
    padding: 12px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    color: #e5e5e5;
    min-width: 200px;
    max-width: 300px;
    animation: slideIn 0.3s ease-out;
    box-shadow: 0 4px 24px 0 rgba(0,0,0,0.5), 0 1.5px 6px 0 rgba(0,0,0,0.4);
  `,!document.getElementById("kortix-toast-styles")){const o=document.createElement("style");o.id="kortix-toast-styles",o.textContent=`
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 300;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Light.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 400;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Regular.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 500;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Medium.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 600;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-SemiBold.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 700;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Bold.ttf")}') format('truetype');
      }
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes fadeOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    `,document.head.appendChild(o)}const t=document.createElement("div");t.style.cssText="width: 20px; height: 20px; flex-shrink: 0;";let r=document.createElement("span");switch(r.style.fontWeight="500",n){case"loading":t.innerHTML=`
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 6V2" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 22V18" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.3"/>
          <path d="M20.49 8.51L18.36 6.38" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.7"/>
          <path d="M5.64 17.64L3.51 15.51" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.5"/>
          <path d="M22 12H18" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.8"/>
          <path d="M6 12H2" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
          <path d="M20.49 15.49L18.36 17.62" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.9"/>
          <path d="M5.64 6.36L3.51 8.49" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.6"/>
        </svg>
      `,t.style.animation="spin 1s linear infinite",r.textContent="Adding to Memory...";break;case"success":{const o=p.runtime.getURL("/icon-16.png");t.innerHTML=`<img src="${o}" width="20" height="20" alt="Success" style="border-radius: 2px;" />`,r.textContent="Added to Memory";break}case"error":{t.innerHTML=`
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="10" fill="#ef4444"/>
          <path d="M15 9L9 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M9 9L15 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      `;const o=document.createElement("div");o.style.cssText="display: flex; flex-direction: column; gap: 2px;";const s=document.createElement("span");s.style.cssText="font-weight: 500; line-height: 1.2;",s.textContent="Failed to save memory";const i=document.createElement("span");i.style.cssText="font-size: 12px; color: #737373; font-weight: 400; line-height: 1.2;",i.textContent="Make sure you are logged in",o.appendChild(s),o.appendChild(i),r=o;break}}return e.appendChild(t),e.appendChild(r),e}function le(n){const e=document.createElement("div");e.id=T.TWITTER_IMPORT_BUTTON,e.style.cssText=`
    position: fixed;
    top: 10px;
    right: 10px;
    z-index: 2147483646;
    background: #0a0a0a;
    color: #e5e5e5;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 50px;
    padding: 10px 12px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4);
  `;const t=p.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
    <span style="font-weight: 500; font-size: 12px;">Import Bookmarks</span>
  `,e.addEventListener("mouseenter",()=>{e.style.opacity="0.8",e.style.boxShadow="0 4px 12px rgba(0,0,0,0.6)"}),e.addEventListener("mouseleave",()=>{e.style.opacity="1",e.style.boxShadow="0 2px 8px rgba(0,0,0,0.4)"}),e.addEventListener("click",n),e}function me(n){const e=document.createElement("div");e.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: auto;
    height: 24px;
    cursor: pointer;
    transition: opacity 0.2s ease;
    border-radius: 50%;
  `;const r=p.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${r}" width="20" height="20" alt="Save to Memory" style="border-radius: 50%;" />
  `,e.addEventListener("mouseenter",()=>{e.style.opacity="0.8"}),e.addEventListener("mouseleave",()=>{e.style.opacity="1"}),e.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),n()}),e}function ue(n){const e=document.createElement("div");e.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: auto;
    height: 32px;
    cursor: pointer;
    transition: all 0.2s ease;
    border-radius: 6px;
    background: transparent;
  `;const r=p.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${r}" width="20" height="20" alt="Get Related Memories from Kortix" style="border-radius: 4px;" />
  `,e.addEventListener("mouseenter",()=>{e.style.backgroundColor="rgba(255, 255, 255, 0.05)",e.style.borderColor="rgba(255, 255, 255, 0.15)"}),e.addEventListener("mouseleave",()=>{e.style.backgroundColor="transparent",e.style.borderColor="rgba(255, 255, 255, 0.1)"}),e.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),n()}),e}function pe(n){const e=document.createElement("div");e.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: auto;
    height: 32px;
    cursor: pointer;
    transition: all 0.2s ease;
    border-radius: 6px;
    background: transparent;
  `;const r=p.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${r}" width="20" height="20" alt="Get Related Memories from Kortix" style="border-radius: 4px;" />
  `,e.addEventListener("mouseenter",()=>{e.style.backgroundColor="rgba(255, 255, 255, 0.05)",e.style.borderColor="rgba(255, 255, 255, 0.15)"}),e.addEventListener("mouseleave",()=>{e.style.backgroundColor="transparent",e.style.borderColor="rgba(255, 255, 255, 0.1)"}),e.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),n()}),e}const m={isOnDomain(n){return n.includes(window.location.hostname)},isDarkMode(){return document.documentElement.getAttribute("style")?.includes("color-scheme: dark")||!1},elementExists(n){return!!document.getElementById(n)},removeElement(n){document.getElementById(n)?.remove()},showToast(n,e=w.TOAST_DURATION){const t=document.getElementById(T.KORTIX_TOAST);if((n==="success"||n==="error")&&t){const s=t.querySelector("div"),i=t.querySelector("span");if(s&&i){if(n==="success"){const a=p.runtime.getURL("/icon-16.png");s.innerHTML=`<img src="${a}" width="20" height="20" alt="Success" style="border-radius: 2px;" />`,s.style.animation="",i.textContent="Added to Memory"}else if(n==="error"){s.innerHTML=`
						<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<circle cx="12" cy="12" r="10" fill="#ef4444"/>
							<path d="M15 9L9 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							<path d="M9 9L15 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
					`,s.style.animation="";const a=document.createElement("div");a.style.cssText="display: flex; flex-direction: column; gap: 2px;";const l=document.createElement("span");l.style.cssText="font-weight: 500; line-height: 1.2;",l.textContent="Failed to save memory";const c=document.createElement("span");c.style.cssText="font-size: 12px; color: #737373; font-weight: 400; line-height: 1.2;",c.textContent="Make sure you are logged in",a.appendChild(l),a.appendChild(c),i.innerHTML="",i.appendChild(a)}return setTimeout(()=>{document.body.contains(t)&&(t.style.animation="fadeOut 0.3s ease-out",setTimeout(()=>{document.body.contains(t)&&t.remove()},300))},e),t}}document.querySelectorAll(`#${T.KORTIX_TOAST}`).forEach(s=>{s.remove()});const o=de(n);return document.body.appendChild(o),(n==="success"||n==="error")&&setTimeout(()=>{document.body.contains(o)&&(o.style.animation="fadeOut 0.3s ease-out",setTimeout(()=>{document.body.contains(o)&&o.remove()},300))},e),o}};let G=null,P=null,k=null,S=null;function Z(){m.isOnDomain(E.CHATGPT)&&(document.body.hasAttribute("data-chatgpt-initialized")||(setTimeout(()=>{F(),K(),H()},2e3),ge(),fe(),document.body.setAttribute("data-chatgpt-initialized","true")))}function fe(){P&&P.disconnect(),k&&clearInterval(k),S&&(clearTimeout(S),S=null);let n=window.location.href;const e=()=>{window.location.href!==n&&(n=window.location.href,console.log("ChatGPT route changed, re-adding kortix elements"),setTimeout(()=>{F(),K(),H()},1e3))};k=setInterval(e,2e3),P=new MutationObserver(t=>{if(S)return;let r=!1;t.forEach(o=>{o.type==="childList"&&o.addedNodes.length>0&&o.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){const i=s;(i.querySelector?.("#prompt-textarea")||i.querySelector?.("button.composer-btn")||i.querySelector?.('[role="dialog"]')||i.matches?.("#prompt-textarea")||i.id==="prompt-textarea")&&(r=!0)}})}),r&&(S=setTimeout(()=>{try{S=null,F(),K(),H()}catch(o){console.error("Error in ChatGPT observer callback:",o)}},300))});try{P.observe(document.body,{childList:!0,subtree:!0})}catch(t){console.error("Failed to set up ChatGPT route observer:",t),k&&clearInterval(k),k=setInterval(e,1e3)}}async function ee(n){try{const e=document.getElementById("prompt-textarea")?.textContent||"",r=document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]')[0];if(!r){console.warn("ChatGPT icon element not found, cannot update feedback");return}A("Searching memories...",r);const o=new Promise((i,a)=>setTimeout(()=>a(new Error("Memory search timeout")),w.API_REQUEST_TIMEOUT)),s=await Promise.race([p.runtime.sendMessage({action:g.GET_RELATED_MEMORIES,data:e,actionSource:n}),o]);if(s?.success&&s?.data){const i=document.getElementById("prompt-textarea");i?(i.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${s.data}</div>`,console.log("Prompt element dataset:",i.dataset.supermemories),r.dataset.memoriesData=s.data,A("Included Memories",r)):(console.warn("ChatGPT prompt element not found after successful memory fetch"),A("Memories found",r))}else console.warn("No memories found or API response invalid"),A("No memories found",r)}catch(e){console.error("Error getting related memories:",e);try{const t=document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]')[0];t&&A("Error fetching memories",t)}catch(t){console.error("Failed to update error feedback:",t)}}}function F(){const n=document.querySelectorAll('[role="dialog"]');let e=null;for(const s of n)if(s.querySelector("h2")?.textContent?.includes("Saved memories")){e=s;break}if(!e||e.querySelector("#kortix-save-button"))return;const t=e.querySelector(".mt-5.flex.justify-end");if(!t)return;const r=document.createElement("button");r.id="kortix-save-button",r.className="btn relative btn-primary-outline mr-2";const o=p.runtime.getURL("/icon-16.png");r.innerHTML=`
        <div class="flex items-center justify-center gap-2">
          <img src="${o}" alt="kortix" style="width: 16px; height: 16px; flex-shrink: 0; border-radius: 2px;" />
          Save to kortix
        </div>
      `,r.style.cssText=`
        background: #1C2026 !important;
        color: white !important;
        border: 1px solid #1C2026 !important;
        border-radius: 9999px !important;
        padding: 10px 16px !important;
        font-weight: 500 !important;
        font-size: 14px !important;
        margin-right: 8px !important;
        cursor: pointer !important;
      `,r.addEventListener("mouseenter",()=>{r.style.backgroundColor="#2B2E33"}),r.addEventListener("mouseleave",()=>{r.style.backgroundColor="#1C2026"}),r.addEventListener("click",async()=>{await he()}),t.insertBefore(r,t.firstChild)}async function he(){try{m.showToast("loading");const n=document.querySelector('[role="dialog"] table tbody');if(!n){m.showToast("error");return}const e=n.querySelectorAll("tr"),t=[];if(e.forEach(s=>{const i=s.querySelector("td .py-2.whitespace-pre-wrap");i?.textContent&&t.push(i.textContent.trim())}),console.log("Memories:",t),t.length===0){m.showToast("error");return}const r=`ChatGPT Saved Memories:

${t.map((s,i)=>`${i+1}. ${s}`).join(`

`)}`,o=await p.runtime.sendMessage({action:g.SAVE_MEMORY,data:{html:r},actionSource:"chatgpt_memories_dialog"});console.log({response:o}),o.success?m.showToast("success"):m.showToast("error")}catch(n){console.error("Error saving memories to kortix:",n),m.showToast("error")}}function A(n,e,t=0){e.dataset.originalHtml||(e.dataset.originalHtml=e.innerHTML);const r=document.createElement("div");if(r.style.cssText=`
		display: flex; 
		align-items: center; 
		gap: 6px; 
		padding: 4px 8px; 
		background: #513EA9; 
		border-radius: 12px; 
		color: white; 
		font-size: 12px; 
		font-weight: 500;
		cursor: ${n==="Included Memories"?"pointer":"default"};
		position: relative;
	`,r.innerHTML=`
		<span>✓</span>
		<span>${n}</span>
	`,n==="Included Memories"&&e.dataset.memoriesData){const o=document.createElement("div");o.style.cssText=`
			position: fixed;
			bottom: 80px;
			left: 50%;
			transform: translateX(-50%);
			background: #1a1a1a;
			color: white;
			padding: 0;
			border-radius: 12px;
			font-size: 13px;
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
			max-width: 500px;
			max-height: 400px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			z-index: 999999;
			display: none;
			border: 1px solid #333;
		`;const s=document.createElement("div");s.style.cssText=`
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px;
			border-bottom: 1px solid #333;
			opacity: 0.8;
		`,s.innerHTML=`
			<span style="font-weight: 600; color: #fff;">Included Memories</span>
		`;const i=document.createElement("div");i.style.cssText=`
			padding: 0;
			max-height: 300px;
			overflow-y: auto;
		`;const a=e.dataset.memoriesData||"";console.log("Memories text:",a);const l=a.split(/[,\n]/).map(c=>c.trim()).filter(c=>c.length>0&&c!==",");console.log("Individual memories:",l),l.forEach((c,y)=>{const u=document.createElement("div");u.style.cssText=`
				display: flex;
				align-items: center;
				gap: 6px;
				padding: 10px;
				font-size: 13px;
				line-height: 1.4;
			`;const f=document.createElement("div");f.style.cssText=`
				flex: 1;
				color: #e5e5e5;
			`,f.textContent=c.trim();const d=document.createElement("button");d.style.cssText=`
				background: transparent;
				color: #9ca3af;
				border: none;
				padding: 4px;
				border-radius: 4px;
				cursor: pointer;
				flex-shrink: 0;
				height: fit-content;
				display: flex;
				align-items: center;
				justify-content: center;
			`,d.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',d.dataset.memoryIndex=y.toString(),d.addEventListener("mouseenter",()=>{d.style.color="#ef4444"}),d.addEventListener("mouseleave",()=>{d.style.color="#9ca3af"}),u.appendChild(f),u.appendChild(d),i.appendChild(u)}),o.appendChild(s),o.appendChild(i),document.body.appendChild(o),r.addEventListener("mouseenter",()=>{const c=r.querySelector("span:last-child");c&&(c.textContent="Click to see memories")}),r.addEventListener("mouseleave",()=>{const c=r.querySelector("span:last-child");c&&(c.textContent="Included Memories")}),r.addEventListener("click",c=>{c.stopPropagation(),o.style.display="block"}),document.addEventListener("click",c=>{o.contains(c.target)||(o.style.display="none")}),i.querySelectorAll("button[data-memory-index]").forEach(c=>{const y=c;y.addEventListener("click",()=>{const u=Number.parseInt(y.dataset.memoryIndex||"0",10),f=y.parentElement;f&&i.removeChild(f);const d=(e.dataset.memoriesData||"").split(/[,\n]/).map(h=>h.trim()).filter(h=>h.length>0&&h!==",");d.splice(u,1);const v=d.join(" ,");e.dataset.memoriesData=v;const x=document.getElementById("prompt-textarea");x&&(x.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${v}</div>`),i.querySelectorAll("button[data-memory-index]").forEach((h,O)=>{const D=h;D.dataset.memoryIndex=O.toString()}),d.length<=1&&(x?.dataset.supermemories&&(delete x.dataset.supermemories,delete e.dataset.memoriesData,e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml),o.style.display="none",document.body.contains(o)&&document.body.removeChild(o))})}),setTimeout(()=>{document.body.contains(o)&&document.body.removeChild(o)},3e5)}e.innerHTML="",e.appendChild(r),t>0&&setTimeout(()=>{e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml},t)}function K(){document.querySelectorAll("button.composer-btn").forEach(e=>{if(e.hasAttribute("data-kortix-icon-added-before"))return;const t=e.parentElement;if(!t)return;const r=t.parentElement?.children;if(!r)return;let o=!1;for(const l of r)if(l.getAttribute("data-testid")==="composer-speech-button-container"){o=!0;break}if(!o)return;const s=t.parentElement;if(!s)return;if(s.querySelector(`#${T.CHATGPT_INPUT_BAR_ELEMENT}-before-composer`)){e.setAttribute("data-kortix-icon-added-before","true");return}const a=me(async()=>{await ee("chatgpt_chat_memories_searched")});a.id=`${T.CHATGPT_INPUT_BAR_ELEMENT}-before-composer-${Date.now()}-${Math.random().toString(36).substring(2,11)}`,e.setAttribute("data-kortix-icon-added-before","true"),s.insertBefore(a,t),H()})}async function H(){if(!((await chrome.storage.local.get([b.AUTO_SEARCH_ENABLED]))[b.AUTO_SEARCH_ENABLED]??!1))return;const t=document.getElementById("prompt-textarea");if(!t||t.hasAttribute("data-kortix-auto-fetch"))return;t.setAttribute("data-kortix-auto-fetch","true");const r=()=>{G&&clearTimeout(G),G=setTimeout(async()=>{const o=t.textContent?.trim()||"";o.length>2?await ee("chatgpt_chat_memories_auto_searched"):o.length===0&&(document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t.dataset.supermemories&&delete t.dataset.supermemories)},w.AUTO_SEARCH_DEBOUNCE_DELAY)};t.addEventListener("input",r)}function ge(){if(document.body.hasAttribute("data-chatgpt-prompt-capture-setup"))return;document.body.setAttribute("data-chatgpt-prompt-capture-setup","true");const n=async e=>{const t=document.getElementById("prompt-textarea");let r="";t&&(r=t.textContent||"");const o=t?.dataset.supermemories;if(o&&t&&!r.includes("Kortix memories of user")&&(t.innerHTML=`${t.innerHTML} ${o}`,r=t.textContent||""),t&&r.trim()){console.log(`ChatGPT prompt submitted via ${e}:`,r);try{await p.runtime.sendMessage({action:g.CAPTURE_PROMPT,data:{prompt:r,platform:"chatgpt",source:e}})}catch(i){console.error("Error sending ChatGPT prompt to background:",i)}}document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t?.dataset.supermemories&&delete t.dataset.supermemories};document.addEventListener("click",async e=>{const t=e.target;(t.id==="composer-submit-button"||t.closest("#composer-submit-button"))&&await n("button click")},!0),document.addEventListener("keydown",async e=>{e.target.id==="prompt-textarea"&&e.key==="Enter"&&!e.shiftKey&&await n("Enter key")},!0)}let z=null,N=null,C=null,M=null;function te(){m.isOnDomain(E.CLAUDE)&&(document.body.hasAttribute("data-claude-initialized")||(setTimeout(()=>{j(),W()},2e3),Te(),ye(),document.body.setAttribute("data-claude-initialized","true")))}function ye(){N&&N.disconnect(),C&&clearInterval(C),M&&(clearTimeout(M),M=null);let n=window.location.href;const e=()=>{window.location.href!==n&&(n=window.location.href,console.log("Claude route changed, re-adding kortix icon"),setTimeout(()=>{j(),W()},1e3))};C=setInterval(e,2e3),N=new MutationObserver(t=>{if(M)return;let r=!1;t.forEach(o=>{o.type==="childList"&&o.addedNodes.length>0&&o.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){const i=s;(i.querySelector?.('div[contenteditable="true"]')||i.querySelector?.("textarea")||i.matches?.('div[contenteditable="true"]')||i.matches?.("textarea"))&&(r=!0)}})}),r&&(M=setTimeout(()=>{try{M=null,j(),W()}catch(o){console.error("Error in Claude observer callback:",o)}},300))});try{N.observe(document.body,{childList:!0,subtree:!0})}catch(t){console.error("Failed to set up Claude route observer:",t),C&&clearInterval(C),C=setInterval(e,1e3)}}function j(){document.querySelectorAll(".relative.flex-1.flex.items-center.gap-2.shrink.min-w-0").forEach(e=>{if(e.hasAttribute("data-kortix-icon-added"))return;if(e.querySelector(`#${T.CLAUDE_INPUT_BAR_ELEMENT}`)){e.setAttribute("data-kortix-icon-added","true");return}const r=ue(async()=>{await oe("claude_chat_memories_searched")});r.id=`${T.CLAUDE_INPUT_BAR_ELEMENT}-${Date.now()}-${Math.random().toString(36).substring(2,11)}`,e.setAttribute("data-kortix-icon-added","true"),e.insertBefore(r,e.firstChild)})}async function oe(n){try{let e="";const t=document.querySelector('[data-kortix-icon-added="true"]');if(t?.parentElement?.previousElementSibling){const a=t.parentElement.previousElementSibling.querySelector("p");e=a?.innerText||a?.textContent||""}if(!e.trim()){const a=document.querySelector('div[contenteditable="true"]');e=a?.innerText||a?.textContent||""}if(!e.trim()){const a=document.querySelectorAll('div[contenteditable="true"], textarea, input[type="text"]');for(const l of a){const c=l.innerText||l.value;if(c?.trim()){e=c.trim();break}}}if(console.log("Claude query extracted:",e),!e.trim()){console.log("No query text found for Claude");return}const o=document.querySelector('[id*="sm-claude-input-bar-element"]');if(!o){console.warn("Claude icon element not found, cannot update feedback");return}_("Searching memories...",o);const s=new Promise((a,l)=>setTimeout(()=>l(new Error("Memory search timeout")),w.API_REQUEST_TIMEOUT)),i=await Promise.race([p.runtime.sendMessage({action:g.GET_RELATED_MEMORIES,data:e,actionSource:n}),s]);if(console.log("Claude memories response:",i),i?.success&&i?.data){const a=document.querySelector('div[contenteditable="true"]');a?(a.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${i.data}</div>`,console.log("Text element dataset:",a.dataset.supermemories),o.dataset.memoriesData=i.data,_("Included Memories",o)):(console.warn("Claude input area not found after successful memory fetch"),_("Memories found",o))}else console.warn("No memories found or API response invalid for Claude"),_("No memories found",o)}catch(e){console.error("Error getting related memories for Claude:",e);try{const t=document.querySelector('[id*="sm-claude-input-bar-element"]');t&&_("Error fetching memories",t)}catch(t){console.error("Failed to update Claude error feedback:",t)}}}function _(n,e,t=0){e.dataset.originalHtml||(e.dataset.originalHtml=e.innerHTML);const r=document.createElement("div");if(r.style.cssText=`
		display: flex; 
		align-items: center; 
		gap: 6px; 
		padding: 6px 8px; 
		background: #513EA9; 
		border-radius: 6px; 
		color: white; 
		font-size: 12px; 
		font-weight: 500;
		cursor: ${n==="Included Memories"?"pointer":"default"};
		position: relative;
	`,r.innerHTML=`
		<span>✓</span>
		<span>${n}</span>
	`,n==="Included Memories"&&e.dataset.memoriesData){const o=document.createElement("div");o.style.cssText=`
			position: fixed;
			bottom: 80px;
			left: 50%;
			transform: translateX(-50%);
			background: #1a1a1a;
			color: white;
			padding: 0;
			border-radius: 12px;
			font-size: 13px;
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
			max-width: 500px;
			max-height: 400px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			z-index: 999999;
			display: none;
			border: 1px solid #333;
		`;const s=document.createElement("div");s.style.cssText=`
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px;
			border-bottom: 1px solid #333;
			opacity: 0.8;
		`,s.innerHTML=`
			<span style="font-weight: 600; color: #fff;">Included Memories</span>
		`;const i=document.createElement("div");i.style.cssText=`
			padding: 0;
			max-height: 300px;
			overflow-y: auto;
		`;const a=e.dataset.memoriesData||"";console.log("Memories text:",a);const l=a.split(/[,\n]/).map(c=>c.trim()).filter(c=>c.length>0&&c!==",");console.log("Individual memories:",l),l.forEach((c,y)=>{const u=document.createElement("div");u.style.cssText=`
				display: flex;
				align-items: center;
				gap: 6px;
				padding: 10px;
				font-size: 13px;
				line-height: 1.4;
			`;const f=document.createElement("div");f.style.cssText=`
				flex: 1;
				color: #e5e5e5;
			`,f.textContent=c.trim();const d=document.createElement("button");d.style.cssText=`
				background: transparent;
				color: #9ca3af;
				border: none;
				padding: 4px;
				border-radius: 4px;
				cursor: pointer;
				flex-shrink: 0;
				height: fit-content;
				display: flex;
				align-items: center;
				justify-content: center;
			`,d.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',d.dataset.memoryIndex=y.toString(),d.addEventListener("mouseenter",()=>{d.style.color="#ef4444"}),d.addEventListener("mouseleave",()=>{d.style.color="#9ca3af"}),u.appendChild(f),u.appendChild(d),i.appendChild(u)}),o.appendChild(s),o.appendChild(i),document.body.appendChild(o),r.addEventListener("mouseenter",()=>{const c=r.querySelector("span:last-child");c&&(c.textContent="Click to see memories")}),r.addEventListener("mouseleave",()=>{const c=r.querySelector("span:last-child");c&&(c.textContent="Included Memories")}),r.addEventListener("click",c=>{c.stopPropagation(),o.style.display="block"}),document.addEventListener("click",c=>{o.contains(c.target)||(o.style.display="none")}),i.querySelectorAll("button[data-memory-index]").forEach(c=>{const y=c;y.addEventListener("click",()=>{const u=Number.parseInt(y.dataset.memoryIndex||"0",10),f=y.parentElement;f&&i.removeChild(f);const d=(e.dataset.memoriesData||"").split(/[,\n]/).map(h=>h.trim()).filter(h=>h.length>0&&h!==",");d.splice(u,1);const v=d.join(" ,");e.dataset.memoriesData=v;const x=document.querySelector('div[contenteditable="true"]');x&&(x.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${v}</div>`),i.querySelectorAll("button[data-memory-index]").forEach((h,O)=>{const D=h;D.dataset.memoryIndex=O.toString()}),d.length<=1&&(x?.dataset.supermemories&&(delete x.dataset.supermemories,delete e.dataset.memoriesData,e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml),o.style.display="none",document.body.contains(o)&&document.body.removeChild(o))})}),setTimeout(()=>{document.body.contains(o)&&document.body.removeChild(o)},3e5)}e.innerHTML="",e.appendChild(r),t>0&&setTimeout(()=>{e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml},t)}function Te(){if(document.body.hasAttribute("data-claude-prompt-capture-setup"))return;document.body.setAttribute("data-claude-prompt-capture-setup","true");const n=async e=>{let t="";const r=document.querySelector('div[contenteditable="true"]');if(r&&(t=r.textContent||r.innerText||""),!t){const i=document.querySelector("textarea");i&&(t=i.value||"")}const o=r?.dataset.supermemories;if(o&&r&&!t.includes("Kortix memories of user")&&(r.innerHTML=`${r.innerHTML} ${o}`,t=r.textContent||r.innerText||""),t.trim()){console.log(`Claude prompt submitted via ${e}:`,t);try{await p.runtime.sendMessage({action:g.CAPTURE_PROMPT,data:{prompt:t,platform:"claude",source:e}})}catch(i){console.error("Error sending Claude prompt to background:",i)}}document.querySelectorAll('[id*="sm-claude-input-bar-element"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),r?.dataset.supermemories&&delete r.dataset.supermemories};document.addEventListener("click",async e=>{const t=e.target;(t.closest("button.inline-flex.items-center.justify-center.relative.shrink-0.can-focus.select-none")||t.closest('button[class*="bg-accent-main-000"]')||t.closest('button[class*="rounded-lg"]'))&&await n("button click")},!0),document.addEventListener("keydown",async e=>{const t=e.target;(t.matches('div[contenteditable="true"]')||t.matches(".ProseMirror")||t.matches("textarea")||t.closest(".ProseMirror"))&&e.key==="Enter"&&!e.shiftKey&&await n("Enter key")},!0)}async function W(){if(!((await chrome.storage.local.get([b.AUTO_SEARCH_ENABLED]))[b.AUTO_SEARCH_ENABLED]??!1))return;const t=document.querySelector('div[contenteditable="true"]');if(!t||t.hasAttribute("data-kortix-auto-fetch"))return;t.setAttribute("data-kortix-auto-fetch","true");const r=()=>{z&&clearTimeout(z),z=setTimeout(async()=>{const o=t.textContent?.trim()||"";o.length>2?await oe("claude_chat_memories_auto_searched"):o.length===0&&(document.querySelectorAll('[id*="sm-claude-input-bar-element"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t.dataset.supermemories&&delete t.dataset.supermemories)},w.AUTO_SEARCH_DEBOUNCE_DELAY)};t.addEventListener("input",r)}const xe=["youtube.com","www.youtube.com","youtu.be","m.youtube.com","music.youtube.com"];function Ee(n){try{const e=new URL(n).hostname;return xe.some(t=>e===t||e.endsWith(`.${t}`))}catch{return!1}}async function re(){try{m.showToast("loading");const n=window.getSelection()?.toString()||"",e=window.location.href,t=document.title,r=Ee(e),o=r?"":document.documentElement.outerHTML,s=await p.runtime.sendMessage({action:g.SAVE_MEMORY,data:{html:o,highlightedText:n,url:e,title:t,isLink:r},actionSource:"context_menu"});console.log("Response from enxtension:",s),s.success?m.showToast("success"):m.showToast("error")}catch(n){console.error("Error saving memory:",n),m.showToast("error")}}function be(){document.addEventListener("keydown",async n=>{(n.ctrlKey||n.metaKey)&&n.shiftKey&&n.key==="m"&&(n.preventDefault(),await re())})}function ve(){window.addEventListener("message",n=>{if(!n.data||typeof n.data!="object")return;const e=n.data.token,t=n.data.refreshToken,r=n.data.userData;if(e&&r){if(!E.KORTIX.includes(window.location.hostname))return;chrome.storage.local.set({[b.BEARER_TOKEN]:e,[b.USER_DATA]:r,...t&&{[b.REFRESH_TOKEN]:t}},()=>{})}})}let X=null,U=null,I=null,L=null;function ne(){m.isOnDomain(E.T3)&&(document.body.hasAttribute("data-t3-initialized")||(setTimeout(()=>{console.log("Adding kortix icon to T3 input"),Y(),V()},2e3),ke(),we(),document.body.setAttribute("data-t3-initialized","true")))}function we(){U&&U.disconnect(),I&&clearInterval(I),L&&(clearTimeout(L),L=null);let n=window.location.href;const e=()=>{window.location.href!==n&&(n=window.location.href,console.log("T3 route changed, re-adding kortix icon"),setTimeout(()=>{Y(),V()},1e3))};I=setInterval(e,2e3),U=new MutationObserver(t=>{if(L)return;let r=!1;t.forEach(o=>{o.type==="childList"&&o.addedNodes.length>0&&o.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){const i=s;(i.querySelector?.("textarea")||i.querySelector?.('div[contenteditable="true"]')||i.matches?.("textarea")||i.matches?.('div[contenteditable="true"]'))&&(r=!0)}})}),r&&(L=setTimeout(()=>{try{L=null,Y(),V()}catch(o){console.error("Error in T3 observer callback:",o)}},300))});try{U.observe(document.body,{childList:!0,subtree:!0})}catch(t){console.error("Failed to set up T3 route observer:",t),I&&clearInterval(I),I=setInterval(e,1e3)}}function Y(){document.querySelectorAll(".flex.min-w-0.items-center.gap-2.overflow-hidden").forEach(e=>{if(e.hasAttribute("data-kortix-icon-added"))return;if(e.querySelector(`#${T.T3_INPUT_BAR_ELEMENT}`)){e.setAttribute("data-kortix-icon-added","true");return}const r=pe(async()=>{await ie("t3_chat_memories_searched")});r.id=`${T.T3_INPUT_BAR_ELEMENT}-${Date.now()}-${Math.random().toString(36).substring(2,11)}`,e.setAttribute("data-kortix-icon-added","true"),e.insertBefore(r,e.firstChild)})}async function ie(n){try{let e="";const t=document.querySelector('[data-kortix-icon-added="true"]');if(t?.parentElement?.parentElement?.previousElementSibling&&(e=t.parentElement.parentElement.previousElementSibling.querySelector("textarea")?.value||""),!e.trim()){const a=document.querySelector('div[contenteditable="true"]');e=a?.innerText||a?.textContent||""}if(!e.trim()){const a=document.querySelectorAll("textarea");for(const l of a){const c=l.value;if(c?.trim()){e=c.trim();break}}}if(console.log("T3 query extracted:",e),!e.trim()){console.log("No query text found for T3");return}const o=document.querySelector('[id*="sm-t3-input-bar-element"]');if(!o){console.warn("T3 icon element not found, cannot update feedback");return}R("Searching memories...",o);const s=new Promise((a,l)=>setTimeout(()=>l(new Error("Memory search timeout")),w.API_REQUEST_TIMEOUT)),i=await Promise.race([p.runtime.sendMessage({action:g.GET_RELATED_MEMORIES,data:e,actionSource:n}),s]);if(console.log("T3 memories response:",i),i?.success&&i?.data){let a=null;const l=document.querySelector('[data-kortix-icon-added="true"]');l?.parentElement?.parentElement?.previousElementSibling&&(a=l.parentElement.parentElement.previousElementSibling.querySelector("textarea")),a||(a=document.querySelector('div[contenteditable="true"]')),a?(a.tagName==="TEXTAREA"?a.dataset.supermemories=`<br>Kortix memories of user (only for the reference): ${i.data}</br>`:a.dataset.supermemories=`<br>Kortix memories of user (only for the reference): ${i.data}</br>`,o.dataset.memoriesData=i.data,R("Included Memories",o)):(console.warn("T3 input area not found after successful memory fetch"),R("Memories found",o))}else console.warn("No memories found or API response invalid for T3"),R("No memories found",o)}catch(e){console.error("Error getting related memories for T3:",e);try{const t=document.querySelector('[id*="sm-t3-input-bar-element"]');t&&R("Error fetching memories",t)}catch(t){console.error("Failed to update T3 error feedback:",t)}}}function R(n,e,t=0){e.dataset.originalHtml||(e.dataset.originalHtml=e.innerHTML);const r=document.createElement("div");if(r.style.cssText=`
		display: flex; 
		align-items: center; 
		gap: 6px; 
		padding: 6px 8px; 
		background: #513EA9; 
		border-radius: 6px; 
		color: white; 
		font-size: 12px; 
		font-weight: 500;
		cursor: ${n==="Included Memories"?"pointer":"default"};
		position: relative;
	`,r.innerHTML=`
		<span>✓</span>
		<span>${n}</span>
	`,n==="Included Memories"&&e.dataset.memoriesData){const o=document.createElement("div");o.style.cssText=`
			position: fixed;
			bottom: 80px;
			left: 50%;
			transform: translateX(-50%);
			background: #1a1a1a;
			color: white;
			padding: 0;
			border-radius: 12px;
			font-size: 13px;
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
			max-width: 500px;
			max-height: 400px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			z-index: 999999;
			display: none;
			border: 1px solid #333;
		`;const s=document.createElement("div");s.style.cssText=`
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px;
			border-bottom: 1px solid #333;
			opacity: 0.8;
		`,s.innerHTML=`
			<span style="font-weight: 600; color: #fff;">Included Memories</span>
		`;const i=document.createElement("div");i.style.cssText=`
			padding: 0;
			max-height: 300px;
			overflow-y: auto;
		`;const a=e.dataset.memoriesData||"";console.log("Memories text:",a);const l=a.split(/[,\n]/).map(c=>c.trim()).filter(c=>c.length>0&&c!==",");console.log("Individual memories:",l),l.forEach((c,y)=>{const u=document.createElement("div");u.style.cssText=`
				display: flex;
				align-items: center;
				gap: 6px;
				padding: 10px;
				font-size: 13px;
				line-height: 1.4;
			`;const f=document.createElement("div");f.style.cssText=`
				flex: 1;
				color: #e5e5e5;
			`,f.textContent=c.trim();const d=document.createElement("button");d.style.cssText=`
				background: transparent;
				color: #9ca3af;
				border: none;
				padding: 4px;
				border-radius: 4px;
				cursor: pointer;
				flex-shrink: 0;
				height: fit-content;
				display: flex;
				align-items: center;
				justify-content: center;
			`,d.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',d.dataset.memoryIndex=y.toString(),d.addEventListener("mouseenter",()=>{d.style.color="#ef4444"}),d.addEventListener("mouseleave",()=>{d.style.color="#9ca3af"}),u.appendChild(f),u.appendChild(d),i.appendChild(u)}),o.appendChild(s),o.appendChild(i),document.body.appendChild(o),r.addEventListener("mouseenter",()=>{const c=r.querySelector("span:last-child");c&&(c.textContent="Click to see memories")}),r.addEventListener("mouseleave",()=>{const c=r.querySelector("span:last-child");c&&(c.textContent="Included Memories")}),r.addEventListener("click",c=>{c.stopPropagation(),o.style.display="block"}),document.addEventListener("click",c=>{o.contains(c.target)||(o.style.display="none")}),i.querySelectorAll("button[data-memory-index]").forEach(c=>{const y=c;y.addEventListener("click",()=>{const u=Number.parseInt(y.dataset.memoryIndex||"0",10),f=y.parentElement;f&&i.removeChild(f);const d=(e.dataset.memoriesData||"").split(/[,\n]/).map(h=>h.trim()).filter(h=>h.length>0&&h!==",");d.splice(u,1);const v=d.join(" ,");e.dataset.memoriesData=v;const x=document.querySelector("textarea")||document.querySelector('div[contenteditable="true"]');x&&(x.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${v}</div>`),i.querySelectorAll("button[data-memory-index]").forEach((h,O)=>{const D=h;D.dataset.memoryIndex=O.toString()}),d.length<=1&&(x?.dataset.supermemories&&(delete x.dataset.supermemories,delete e.dataset.memoriesData,e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml),o.style.display="none",document.body.contains(o)&&document.body.removeChild(o))})}),setTimeout(()=>{document.body.contains(o)&&document.body.removeChild(o)},3e5)}e.innerHTML="",e.appendChild(r),t>0&&setTimeout(()=>{e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml},t)}function ke(){if(document.body.hasAttribute("data-t3-prompt-capture-setup"))return;document.body.setAttribute("data-t3-prompt-capture-setup","true");const n=async e=>{let t="";const r=document.querySelector("textarea");if(r&&(t=r.value||""),!t){const a=document.querySelector('div[contenteditable="true"]');a&&(t=a.textContent||a.innerText||"")}const o=r||document.querySelector('div[contenteditable="true"]'),s=o?.dataset.supermemories;if(s&&o&&!t.includes("Kortix memories of user")&&(o.tagName==="TEXTAREA"?(o.value=`${t} ${s}`,t=o.value):(o.innerHTML=`${o.innerHTML} ${s}`,t=o.textContent||o.innerText||"")),t.trim()){console.log(`T3 prompt submitted via ${e}:`,t);try{await p.runtime.sendMessage({action:g.CAPTURE_PROMPT,data:{prompt:t,platform:"t3",source:e}})}catch(a){console.error("Error sending T3 prompt to background:",a)}}document.querySelectorAll('[id*="sm-t3-input-bar-element"]').forEach(a=>{const l=a;l.dataset.originalHtml&&(l.innerHTML=l.dataset.originalHtml,delete l.dataset.originalHtml,delete l.dataset.memoriesData)}),o?.dataset.supermemories&&delete o.dataset.supermemories};document.addEventListener("click",async e=>{const t=e.target;(t.closest("button.focus-visible\\:ring-ring")||t.closest('button[class*="bg-[rgb(162,59,103)]"]')||t.closest('button[class*="rounded-lg"]'))&&await n("button click")},!0),document.addEventListener("keydown",async e=>{const t=e.target;if((t.matches("textarea")||t.matches('div[contenteditable="true"]'))&&e.key==="Enter"&&!e.shiftKey)if(t.matches("textarea")){const r=t.value||"";if(r.trim()){console.log("T3 prompt submitted via Enter key:",r);try{await p.runtime.sendMessage({action:g.CAPTURE_PROMPT,data:{prompt:r,platform:"t3",source:"Enter key"},actionSource:"t3"})}catch(o){console.error("Error sending T3 textarea prompt to background:",o)}}}else await n("Enter key")},!0)}async function V(){if(!((await chrome.storage.local.get([b.AUTO_SEARCH_ENABLED]))[b.AUTO_SEARCH_ENABLED]??!1))return;const t=document.querySelector("textarea")||document.querySelector('div[contenteditable="true"]');if(!t||t.hasAttribute("data-kortix-auto-fetch"))return;t.setAttribute("data-kortix-auto-fetch","true");const r=()=>{X&&clearTimeout(X),X=setTimeout(async()=>{let o="";t.tagName==="TEXTAREA"?o=t.value?.trim()||"":o=t.textContent?.trim()||"",o.length>2?await ie("t3_chat_memories_auto_searched"):o.length===0&&(document.querySelectorAll('[id*="sm-t3-input-bar-element"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t.dataset.supermemories&&delete t.dataset.supermemories)},w.AUTO_SEARCH_DEBOUNCE_DELAY)};t.addEventListener("input",r)}function Se(){m.isOnDomain(E.TWITTER)&&(window.location.pathname==="/i/bookmarks"?setTimeout(()=>{ae()},2e3):m.elementExists(T.TWITTER_IMPORT_BUTTON)&&m.removeElement(T.TWITTER_IMPORT_BUTTON))}function ae(){if(window.location.pathname!=="/i/bookmarks"||m.elementExists(T.TWITTER_IMPORT_BUTTON))return;const n=le(async()=>{try{await p.runtime.sendMessage({type:g.BATCH_IMPORT_ALL})}catch(e){console.error("Error starting import:",e)}});document.body.appendChild(n)}function se(n){const e=document.getElementById(T.TWITTER_IMPORT_BUTTON);if(!e)return;const t=p.runtime.getURL("/icon-16.png");n.type===g.IMPORT_UPDATE&&(e.innerHTML=`
			<img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
			<span style="font-weight: 500; font-size: 14px;">${n.importedMessage}</span>
		`,e.style.cursor="default"),n.type===g.IMPORT_DONE&&(e.innerHTML=`
			<img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
			<span style="font-weight: 500; font-size: 14px; color: #059669;">✓ Imported ${n.totalImported} tweets!</span>
		`,setTimeout(()=>{e.innerHTML=`
				<img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
				<span style="font-weight: 500; font-size: 14px;">Import Bookmarks</span>
			`,e.style.cursor="pointer"},3e3))}function Ce(){m.isOnDomain(E.TWITTER)&&(window.location.pathname==="/i/bookmarks"?ae():m.elementExists(T.TWITTER_IMPORT_BUTTON)&&m.removeElement(T.TWITTER_IMPORT_BUTTON))}const Me={matches:["<all_urls>"],main(){const n=async t=>{const r=`${Date.now()}-${Math.random().toString(36).slice(2)}`;return await new Promise(o=>{const s="kortix-grid-response",i="kortix-grid-request",a=y=>{const u=y.detail;!u||u.requestId!==r||(l(),o({active:!!u.active}))},l=()=>{document.removeEventListener(s,a),window.clearTimeout(c)},c=window.setTimeout(()=>{l(),o({active:"twcStarted"in document.body.dataset})},1200);document.addEventListener(s,a),document.dispatchEvent(new CustomEvent(i,{detail:{requestId:r,command:t}}))})};p.runtime.onMessage.addListener((t,r,o)=>{if(t.action===g.SHOW_TOAST)m.showToast(t.state);else{if(t.action===g.SAVE_MEMORY)return re().then(()=>o({success:!0})).catch(()=>o({success:!1})),!0;if(t.action===g.TOGGLE_X_GRID||t.action===g.GET_X_GRID_STATE){if(!m.isOnDomain(E.TWITTER)){o({active:!1});return}const s=t.action===g.TOGGLE_X_GRID?"toggle":"state";return n(s).then(o).catch(i=>{console.error("Failed to bridge Twitter grid action:",i),o({active:!1})}),!0}else(t.type===g.IMPORT_UPDATE||t.type===g.IMPORT_DONE)&&se(t)}}),be(),ve();const e=()=>{new MutationObserver(()=>{m.isOnDomain(E.CHATGPT)&&Z(),m.isOnDomain(E.CLAUDE)&&te(),m.isOnDomain(E.T3)&&ne(),m.isOnDomain(E.TWITTER)&&Ce()}).observe(document.body,{childList:!0,subtree:!0})};Z(),te(),ne(),Se(),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",e):e()}};function B(n,...e){}const Ie={debug:(...n)=>B(console.debug,...n),log:(...n)=>B(console.log,...n),warn:(...n)=>B(console.warn,...n),error:(...n)=>B(console.error,...n)};class Q extends Event{constructor(e,t){super(Q.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=t}static EVENT_NAME=J("wxt:locationchange")}function J(n){return`${p?.runtime?.id}:content:${n}`}function Le(n){let e,t;return{run(){e==null&&(t=new URL(location.href),e=n.setInterval(()=>{let r=new URL(location.href);r.href!==t.href&&(window.dispatchEvent(new Q(r,t)),t=r)},1e3))}}}class q{constructor(e,t){this.contentScriptName=e,this.options=t,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=J("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=Le(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return p.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,t){const r=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(e,t){const r=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(e){const t=requestAnimationFrame((...r)=>{this.isValid&&e(...r)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){const r=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},t);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(e,t,r,o){t==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith("wxt:")?J(t):t,r,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Ie.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:q.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){const t=e.data?.type===q.SCRIPT_STARTED_MESSAGE_TYPE,r=e.data?.contentScriptName===this.contentScriptName,o=!this.receivedMessageIds.has(e.data?.messageId);return t&&r&&o}listenForNewerScripts(e){let t=!0;const r=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const s=t;if(t=!1,s&&e?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}}function De(){}function $(n,...e){}const Ae={debug:(...n)=>$(console.debug,...n),log:(...n)=>$(console.log,...n),warn:(...n)=>$(console.warn,...n),error:(...n)=>$(console.error,...n)};return(async()=>{try{const{main:n,...e}=Me,t=new q("content",e);return await n(t)}catch(n){throw Ae.error('The content script "content" crashed on startup!',n),n}})()})();
content;