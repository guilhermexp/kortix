var content=(function(){"use strict";function Ne(r){return r}const m=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,ce="https://kortix.claudedokploy.com",b={BEARER_TOKEN:"bearer-token",REFRESH_TOKEN:"refresh-token",USER_DATA:"user-data",AUTO_SEARCH_ENABLED:"sm-auto-search-enabled",SAVE_PAGE_BUTTON_ENABLED:"sm-save-page-button-enabled"},y={TWITTER_IMPORT_BUTTON:"sm-twitter-import-button",KORTIX_TOAST:"sm-toast",SAVE_PAGE_BUTTON:"sm-save-page-button",CHATGPT_INPUT_BAR_ELEMENT:"sm-chatgpt-input-bar-element",CLAUDE_INPUT_BAR_ELEMENT:"sm-claude-input-bar-element",T3_INPUT_BAR_ELEMENT:"sm-t3-input-bar-element"},w={BUTTON_SHOW_DELAY:2e3,TOAST_DURATION:3e3,RATE_LIMIT_BASE_WAIT:6e4,PAGINATION_DELAY:1e3,AUTO_SEARCH_DEBOUNCE_DELAY:1500,OBSERVER_THROTTLE_DELAY:300,ROUTE_CHECK_INTERVAL:2e3,API_REQUEST_TIMEOUT:1e4},E={TWITTER:["x.com","twitter.com"],CHATGPT:["chatgpt.com","chat.openai.com"],CLAUDE:["claude.ai"],T3:["t3.chat"],KORTIX:["localhost",new URL(ce).hostname]},h={SAVE_MEMORY:"sm-save-memory",SHOW_TOAST:"sm-show-toast",BATCH_IMPORT_ALL:"sm-batch-import-all",IMPORT_UPDATE:"sm-import-update",IMPORT_DONE:"sm-import-done",GET_RELATED_MEMORIES:"sm-get-related-memories",CAPTURE_PROMPT:"sm-capture-prompt",TOGGLE_X_GRID:"sm-toggle-x-grid",GET_X_GRID_STATE:"sm-get-x-grid-state",NLM_START_CAPTURE:"sm-nlm-start-capture",NLM_CONNECTED:"NLM_CONNECTED"};function de(r){const e=document.createElement("div");if(e.id=y.KORTIX_TOAST,e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2147483647;
    background: #0a0a0a;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 9999px;
    padding: 12px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    color: #e5e5e5;
    min-width: 200px;
    max-width: 300px;
    animation: slideIn 0.3s ease-out;
    box-shadow: 0 4px 24px 0 rgba(0,0,0,0.5), 0 1.5px 6px 0 rgba(0,0,0,0.4);
  `,!document.getElementById("kortix-toast-styles")){const o=document.createElement("style");o.id="kortix-toast-styles",o.textContent=`
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 300;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Light.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 400;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Regular.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 500;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Medium.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 600;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-SemiBold.ttf")}') format('truetype');
      }
      @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-weight: 700;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/SpaceGrotesk-Bold.ttf")}') format('truetype');
      }
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes fadeOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    `,document.head.appendChild(o)}const t=document.createElement("div");t.style.cssText="width: 20px; height: 20px; flex-shrink: 0;";let n=document.createElement("span");switch(n.style.fontWeight="500",r){case"loading":t.innerHTML=`
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 6V2" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 22V18" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.3"/>
          <path d="M20.49 8.51L18.36 6.38" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.7"/>
          <path d="M5.64 17.64L3.51 15.51" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.5"/>
          <path d="M22 12H18" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.8"/>
          <path d="M6 12H2" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
          <path d="M20.49 15.49L18.36 17.62" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.9"/>
          <path d="M5.64 6.36L3.51 8.49" stroke="#a3a3a3" stroke-width="2" stroke-linecap="round" opacity="0.6"/>
        </svg>
      `,t.style.animation="spin 1s linear infinite",n.textContent="Adding to Memory...";break;case"success":{const o=m.runtime.getURL("/icon-16.png");t.innerHTML=`<img src="${o}" width="20" height="20" alt="Success" style="border-radius: 2px;" />`,n.textContent="Added to Memory";break}case"error":{t.innerHTML=`
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="10" fill="#ef4444"/>
          <path d="M15 9L9 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M9 9L15 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      `;const o=document.createElement("div");o.style.cssText="display: flex; flex-direction: column; gap: 2px;";const s=document.createElement("span");s.style.cssText="font-weight: 500; line-height: 1.2;",s.textContent="Failed to save memory";const i=document.createElement("span");i.style.cssText="font-size: 12px; color: #737373; font-weight: 400; line-height: 1.2;",i.textContent="Make sure you are logged in",o.appendChild(s),o.appendChild(i),n=o;break}}return e.appendChild(t),e.appendChild(n),e}const le=`
    background: #0a0a0a;
    color: #e5e5e5;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 50px;
    padding: 10px 12px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4);
`;function ue(r){r.addEventListener("mouseenter",()=>{r.style.opacity="0.8",r.style.boxShadow="0 4px 12px rgba(0,0,0,0.6)"}),r.addEventListener("mouseleave",()=>{r.style.opacity="1",r.style.boxShadow="0 2px 8px rgba(0,0,0,0.4)"})}function me(r){const e=document.createElement("div");e.id=y.TWITTER_IMPORT_BUTTON,e.style.cssText=`
    position: fixed;
    top: 10px;
    right: 10px;
    z-index: 2147483646;
    ${le}
  `;const t=m.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
    <span style="font-weight: 500; font-size: 12px;">Import Bookmarks</span>
  `,ue(e),e.addEventListener("click",r),e}function pe(r){const e=document.createElement("div");if(e.id=y.SAVE_PAGE_BUTTON,!document.getElementById("kortix-save-page-styles")){const a=document.createElement("style");a.id="kortix-save-page-styles",a.textContent=`
      @keyframes kortix-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    `,document.head.appendChild(a)}e.style.cssText=`
    position: fixed;
    bottom: 16px;
    right: 16px;
    z-index: 2147483647;
    width: 40px;
    height: 40px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    background: rgb(0, 0, 0);
    opacity: 0.7;
    transition: opacity 0.2s, transform 0.2s;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4);
  `;const n=`<img src="${m.runtime.getURL("/icon-16.png")}" width="20" height="20" alt="Save Page" style="border-radius: 4px;" />`,o='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" style="animation: kortix-spin 0.8s linear infinite;"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" stroke="rgba(255,255,255,0.5)" stroke-width="2" stroke-linecap="round"/></svg>',s='<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#22c55e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';e.innerHTML=n;let i=!1;return e.addEventListener("mouseenter",()=>{i||(e.style.opacity="1",e.style.transform="scale(1.1)")}),e.addEventListener("mouseleave",()=>{i||(e.style.opacity="0.7",e.style.transform="scale(1)")}),e.addEventListener("click",async()=>{if(!i){i=!0,e.style.cursor="default",e.style.opacity="1",e.innerHTML=o;try{await r(),e.innerHTML=s,e.style.borderColor="rgba(34, 197, 94, 0.4)"}catch{e.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#ef4444" stroke-width="2.5" stroke-linecap="round"/></svg>',e.style.borderColor="rgba(239, 68, 68, 0.4)"}setTimeout(()=>{e.innerHTML=n,e.style.cursor="pointer",e.style.opacity="0.7",e.style.borderColor="rgba(255, 255, 255, 0.2)",i=!1},2e3)}}),e}function fe(r){const e=document.createElement("div");e.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: auto;
    height: 24px;
    cursor: pointer;
    transition: opacity 0.2s ease;
    border-radius: 50%;
  `;const n=m.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${n}" width="20" height="20" alt="Save to Memory" style="border-radius: 50%;" />
  `,e.addEventListener("mouseenter",()=>{e.style.opacity="0.8"}),e.addEventListener("mouseleave",()=>{e.style.opacity="1"}),e.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),r()}),e}function he(r){const e=document.createElement("div");e.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: auto;
    height: 32px;
    cursor: pointer;
    transition: all 0.2s ease;
    border-radius: 6px;
    background: transparent;
  `;const n=m.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${n}" width="20" height="20" alt="Get Related Memories from Kortix" style="border-radius: 4px;" />
  `,e.addEventListener("mouseenter",()=>{e.style.backgroundColor="rgba(255, 255, 255, 0.05)",e.style.borderColor="rgba(255, 255, 255, 0.15)"}),e.addEventListener("mouseleave",()=>{e.style.backgroundColor="transparent",e.style.borderColor="rgba(255, 255, 255, 0.1)"}),e.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),r()}),e}function ge(r){const e=document.createElement("div");e.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: auto;
    height: 32px;
    cursor: pointer;
    transition: all 0.2s ease;
    border-radius: 6px;
    background: transparent;
  `;const n=m.runtime.getURL("/icon-16.png");return e.innerHTML=`
    <img src="${n}" width="20" height="20" alt="Get Related Memories from Kortix" style="border-radius: 4px;" />
  `,e.addEventListener("mouseenter",()=>{e.style.backgroundColor="rgba(255, 255, 255, 0.05)",e.style.borderColor="rgba(255, 255, 255, 0.15)"}),e.addEventListener("mouseleave",()=>{e.style.backgroundColor="transparent",e.style.borderColor="rgba(255, 255, 255, 0.1)"}),e.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),r()}),e}const u={isOnDomain(r){return r.includes(window.location.hostname)},isDarkMode(){return document.documentElement.getAttribute("style")?.includes("color-scheme: dark")||!1},elementExists(r){return!!document.getElementById(r)},removeElement(r){document.getElementById(r)?.remove()},showToast(r,e=w.TOAST_DURATION){const t=document.getElementById(y.KORTIX_TOAST);if((r==="success"||r==="error")&&t){const s=t.querySelector("div"),i=t.querySelector("span");if(s&&i){if(r==="success"){const a=m.runtime.getURL("/icon-16.png");s.innerHTML=`<img src="${a}" width="20" height="20" alt="Success" style="border-radius: 2px;" />`,s.style.animation="",i.textContent="Added to Memory"}else if(r==="error"){s.innerHTML=`
						<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<circle cx="12" cy="12" r="10" fill="#ef4444"/>
							<path d="M15 9L9 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							<path d="M9 9L15 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
					`,s.style.animation="";const a=document.createElement("div");a.style.cssText="display: flex; flex-direction: column; gap: 2px;";const l=document.createElement("span");l.style.cssText="font-weight: 500; line-height: 1.2;",l.textContent="Failed to save memory";const c=document.createElement("span");c.style.cssText="font-size: 12px; color: #737373; font-weight: 400; line-height: 1.2;",c.textContent="Make sure you are logged in",a.appendChild(l),a.appendChild(c),i.innerHTML="",i.appendChild(a)}return setTimeout(()=>{document.body.contains(t)&&(t.style.animation="fadeOut 0.3s ease-out",setTimeout(()=>{document.body.contains(t)&&t.remove()},300))},e),t}}document.querySelectorAll(`#${y.KORTIX_TOAST}`).forEach(s=>{s.remove()});const o=de(r);return document.body.appendChild(o),(r==="success"||r==="error")&&setTimeout(()=>{document.body.contains(o)&&(o.style.animation="fadeOut 0.3s ease-out",setTimeout(()=>{document.body.contains(o)&&o.remove()},300))},e),o}};let G=null,P=null,k=null,S=null;function ee(){u.isOnDomain(E.CHATGPT)&&(document.body.hasAttribute("data-chatgpt-initialized")||(setTimeout(()=>{F(),K(),D()},2e3),xe(),Te(),document.body.setAttribute("data-chatgpt-initialized","true")))}function Te(){P&&P.disconnect(),k&&clearInterval(k),S&&(clearTimeout(S),S=null);let r=window.location.href;const e=()=>{window.location.href!==r&&(r=window.location.href,console.log("ChatGPT route changed, re-adding kortix elements"),setTimeout(()=>{F(),K(),D()},1e3))};k=setInterval(e,2e3),P=new MutationObserver(t=>{if(S)return;let n=!1;t.forEach(o=>{o.type==="childList"&&o.addedNodes.length>0&&o.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){const i=s;(i.querySelector?.("#prompt-textarea")||i.querySelector?.("button.composer-btn")||i.querySelector?.('[role="dialog"]')||i.matches?.("#prompt-textarea")||i.id==="prompt-textarea")&&(n=!0)}})}),n&&(S=setTimeout(()=>{try{S=null,F(),K(),D()}catch(o){console.error("Error in ChatGPT observer callback:",o)}},300))});try{P.observe(document.body,{childList:!0,subtree:!0})}catch(t){console.error("Failed to set up ChatGPT route observer:",t),k&&clearInterval(k),k=setInterval(e,1e3)}}async function te(r){try{const e=document.getElementById("prompt-textarea")?.textContent||"",n=document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]')[0];if(!n){console.warn("ChatGPT icon element not found, cannot update feedback");return}A("Searching memories...",n);const o=new Promise((i,a)=>setTimeout(()=>a(new Error("Memory search timeout")),w.API_REQUEST_TIMEOUT)),s=await Promise.race([m.runtime.sendMessage({action:h.GET_RELATED_MEMORIES,data:e,actionSource:r}),o]);if(s?.success&&s?.data){const i=document.getElementById("prompt-textarea");i?(i.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${s.data}</div>`,console.log("Prompt element dataset:",i.dataset.supermemories),n.dataset.memoriesData=s.data,A("Included Memories",n)):(console.warn("ChatGPT prompt element not found after successful memory fetch"),A("Memories found",n))}else console.warn("No memories found or API response invalid"),A("No memories found",n)}catch(e){console.error("Error getting related memories:",e);try{const t=document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]')[0];t&&A("Error fetching memories",t)}catch(t){console.error("Failed to update error feedback:",t)}}}function F(){const r=document.querySelectorAll('[role="dialog"]');let e=null;for(const s of r)if(s.querySelector("h2")?.textContent?.includes("Saved memories")){e=s;break}if(!e||e.querySelector("#kortix-save-button"))return;const t=e.querySelector(".mt-5.flex.justify-end");if(!t)return;const n=document.createElement("button");n.id="kortix-save-button",n.className="btn relative btn-primary-outline mr-2";const o=m.runtime.getURL("/icon-16.png");n.innerHTML=`
        <div class="flex items-center justify-center gap-2">
          <img src="${o}" alt="kortix" style="width: 16px; height: 16px; flex-shrink: 0; border-radius: 2px;" />
          Save to kortix
        </div>
      `,n.style.cssText=`
        background: #1C2026 !important;
        color: white !important;
        border: 1px solid #1C2026 !important;
        border-radius: 9999px !important;
        padding: 10px 16px !important;
        font-weight: 500 !important;
        font-size: 14px !important;
        margin-right: 8px !important;
        cursor: pointer !important;
      `,n.addEventListener("mouseenter",()=>{n.style.backgroundColor="#2B2E33"}),n.addEventListener("mouseleave",()=>{n.style.backgroundColor="#1C2026"}),n.addEventListener("click",async()=>{await ye()}),t.insertBefore(n,t.firstChild)}async function ye(){try{u.showToast("loading");const r=document.querySelector('[role="dialog"] table tbody');if(!r){u.showToast("error");return}const e=r.querySelectorAll("tr"),t=[];if(e.forEach(s=>{const i=s.querySelector("td .py-2.whitespace-pre-wrap");i?.textContent&&t.push(i.textContent.trim())}),console.log("Memories:",t),t.length===0){u.showToast("error");return}const n=`ChatGPT Saved Memories:

${t.map((s,i)=>`${i+1}. ${s}`).join(`

`)}`,o=await m.runtime.sendMessage({action:h.SAVE_MEMORY,data:{html:n},actionSource:"chatgpt_memories_dialog"});console.log({response:o}),o.success?u.showToast("success"):u.showToast("error")}catch(r){console.error("Error saving memories to kortix:",r),u.showToast("error")}}function A(r,e,t=0){e.dataset.originalHtml||(e.dataset.originalHtml=e.innerHTML);const n=document.createElement("div");if(n.style.cssText=`
		display: flex; 
		align-items: center; 
		gap: 6px; 
		padding: 4px 8px; 
		background: #513EA9; 
		border-radius: 12px; 
		color: white; 
		font-size: 12px; 
		font-weight: 500;
		cursor: ${r==="Included Memories"?"pointer":"default"};
		position: relative;
	`,n.innerHTML=`
		<span>✓</span>
		<span>${r}</span>
	`,r==="Included Memories"&&e.dataset.memoriesData){const o=document.createElement("div");o.style.cssText=`
			position: fixed;
			bottom: 80px;
			left: 50%;
			transform: translateX(-50%);
			background: #1a1a1a;
			color: white;
			padding: 0;
			border-radius: 12px;
			font-size: 13px;
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
			max-width: 500px;
			max-height: 400px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			z-index: 999999;
			display: none;
			border: 1px solid #333;
		`;const s=document.createElement("div");s.style.cssText=`
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px;
			border-bottom: 1px solid #333;
			opacity: 0.8;
		`,s.innerHTML=`
			<span style="font-weight: 600; color: #fff;">Included Memories</span>
		`;const i=document.createElement("div");i.style.cssText=`
			padding: 0;
			max-height: 300px;
			overflow-y: auto;
		`;const a=e.dataset.memoriesData||"";console.log("Memories text:",a);const l=a.split(/[,\n]/).map(c=>c.trim()).filter(c=>c.length>0&&c!==",");console.log("Individual memories:",l),l.forEach((c,g)=>{const p=document.createElement("div");p.style.cssText=`
				display: flex;
				align-items: center;
				gap: 6px;
				padding: 10px;
				font-size: 13px;
				line-height: 1.4;
			`;const f=document.createElement("div");f.style.cssText=`
				flex: 1;
				color: #e5e5e5;
			`,f.textContent=c.trim();const d=document.createElement("button");d.style.cssText=`
				background: transparent;
				color: #9ca3af;
				border: none;
				padding: 4px;
				border-radius: 4px;
				cursor: pointer;
				flex-shrink: 0;
				height: fit-content;
				display: flex;
				align-items: center;
				justify-content: center;
			`,d.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',d.dataset.memoryIndex=g.toString(),d.addEventListener("mouseenter",()=>{d.style.color="#ef4444"}),d.addEventListener("mouseleave",()=>{d.style.color="#9ca3af"}),p.appendChild(f),p.appendChild(d),i.appendChild(p)}),o.appendChild(s),o.appendChild(i),document.body.appendChild(o),n.addEventListener("mouseenter",()=>{const c=n.querySelector("span:last-child");c&&(c.textContent="Click to see memories")}),n.addEventListener("mouseleave",()=>{const c=n.querySelector("span:last-child");c&&(c.textContent="Included Memories")}),n.addEventListener("click",c=>{c.stopPropagation(),o.style.display="block"}),document.addEventListener("click",c=>{o.contains(c.target)||(o.style.display="none")}),i.querySelectorAll("button[data-memory-index]").forEach(c=>{const g=c;g.addEventListener("click",()=>{const p=Number.parseInt(g.dataset.memoryIndex||"0",10),f=g.parentElement;f&&i.removeChild(f);const d=(e.dataset.memoriesData||"").split(/[,\n]/).map(T=>T.trim()).filter(T=>T.length>0&&T!==",");d.splice(p,1);const v=d.join(" ,");e.dataset.memoriesData=v;const x=document.getElementById("prompt-textarea");x&&(x.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${v}</div>`),i.querySelectorAll("button[data-memory-index]").forEach((T,O)=>{const N=T;N.dataset.memoryIndex=O.toString()}),d.length<=1&&(x?.dataset.supermemories&&(delete x.dataset.supermemories,delete e.dataset.memoriesData,e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml),o.style.display="none",document.body.contains(o)&&document.body.removeChild(o))})}),setTimeout(()=>{document.body.contains(o)&&document.body.removeChild(o)},3e5)}e.innerHTML="",e.appendChild(n),t>0&&setTimeout(()=>{e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml},t)}function K(){document.querySelectorAll("button.composer-btn").forEach(e=>{if(e.hasAttribute("data-kortix-icon-added-before"))return;const t=e.parentElement;if(!t)return;const n=t.parentElement?.children;if(!n)return;let o=!1;for(const l of n)if(l.getAttribute("data-testid")==="composer-speech-button-container"){o=!0;break}if(!o)return;const s=t.parentElement;if(!s)return;if(s.querySelector(`#${y.CHATGPT_INPUT_BAR_ELEMENT}-before-composer`)){e.setAttribute("data-kortix-icon-added-before","true");return}const a=fe(async()=>{await te("chatgpt_chat_memories_searched")});a.id=`${y.CHATGPT_INPUT_BAR_ELEMENT}-before-composer-${Date.now()}-${Math.random().toString(36).substring(2,11)}`,e.setAttribute("data-kortix-icon-added-before","true"),s.insertBefore(a,t),D()})}async function D(){if(!((await chrome.storage.local.get([b.AUTO_SEARCH_ENABLED]))[b.AUTO_SEARCH_ENABLED]??!1))return;const t=document.getElementById("prompt-textarea");if(!t||t.hasAttribute("data-kortix-auto-fetch"))return;t.setAttribute("data-kortix-auto-fetch","true");const n=()=>{G&&clearTimeout(G),G=setTimeout(async()=>{const o=t.textContent?.trim()||"";o.length>2?await te("chatgpt_chat_memories_auto_searched"):o.length===0&&(document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t.dataset.supermemories&&delete t.dataset.supermemories)},w.AUTO_SEARCH_DEBOUNCE_DELAY)};t.addEventListener("input",n)}function xe(){if(document.body.hasAttribute("data-chatgpt-prompt-capture-setup"))return;document.body.setAttribute("data-chatgpt-prompt-capture-setup","true");const r=async e=>{const t=document.getElementById("prompt-textarea");let n="";t&&(n=t.textContent||"");const o=t?.dataset.supermemories;if(o&&t&&!n.includes("Kortix memories of user")&&(t.innerHTML=`${t.innerHTML} ${o}`,n=t.textContent||""),t&&n.trim()){console.log(`ChatGPT prompt submitted via ${e}:`,n);try{await m.runtime.sendMessage({action:h.CAPTURE_PROMPT,data:{prompt:n,platform:"chatgpt",source:e}})}catch(i){console.error("Error sending ChatGPT prompt to background:",i)}}document.querySelectorAll('[id*="sm-chatgpt-input-bar-element-before-composer"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t?.dataset.supermemories&&delete t.dataset.supermemories};document.addEventListener("click",async e=>{const t=e.target;(t.id==="composer-submit-button"||t.closest("#composer-submit-button"))&&await r("button click")},!0),document.addEventListener("keydown",async e=>{e.target.id==="prompt-textarea"&&e.key==="Enter"&&!e.shiftKey&&await r("Enter key")},!0)}let z=null,U=null,M=null,C=null;function oe(){u.isOnDomain(E.CLAUDE)&&(document.body.hasAttribute("data-claude-initialized")||(setTimeout(()=>{X(),j()},2e3),be(),Ee(),document.body.setAttribute("data-claude-initialized","true")))}function Ee(){U&&U.disconnect(),M&&clearInterval(M),C&&(clearTimeout(C),C=null);let r=window.location.href;const e=()=>{window.location.href!==r&&(r=window.location.href,console.log("Claude route changed, re-adding kortix icon"),setTimeout(()=>{X(),j()},1e3))};M=setInterval(e,2e3),U=new MutationObserver(t=>{if(C)return;let n=!1;t.forEach(o=>{o.type==="childList"&&o.addedNodes.length>0&&o.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){const i=s;(i.querySelector?.('div[contenteditable="true"]')||i.querySelector?.("textarea")||i.matches?.('div[contenteditable="true"]')||i.matches?.("textarea"))&&(n=!0)}})}),n&&(C=setTimeout(()=>{try{C=null,X(),j()}catch(o){console.error("Error in Claude observer callback:",o)}},300))});try{U.observe(document.body,{childList:!0,subtree:!0})}catch(t){console.error("Failed to set up Claude route observer:",t),M&&clearInterval(M),M=setInterval(e,1e3)}}function X(){document.querySelectorAll(".relative.flex-1.flex.items-center.gap-2.shrink.min-w-0").forEach(e=>{if(e.hasAttribute("data-kortix-icon-added"))return;if(e.querySelector(`#${y.CLAUDE_INPUT_BAR_ELEMENT}`)){e.setAttribute("data-kortix-icon-added","true");return}const n=he(async()=>{await ne("claude_chat_memories_searched")});n.id=`${y.CLAUDE_INPUT_BAR_ELEMENT}-${Date.now()}-${Math.random().toString(36).substring(2,11)}`,e.setAttribute("data-kortix-icon-added","true"),e.insertBefore(n,e.firstChild)})}async function ne(r){try{let e="";const t=document.querySelector('[data-kortix-icon-added="true"]');if(t?.parentElement?.previousElementSibling){const a=t.parentElement.previousElementSibling.querySelector("p");e=a?.innerText||a?.textContent||""}if(!e.trim()){const a=document.querySelector('div[contenteditable="true"]');e=a?.innerText||a?.textContent||""}if(!e.trim()){const a=document.querySelectorAll('div[contenteditable="true"], textarea, input[type="text"]');for(const l of a){const c=l.innerText||l.value;if(c?.trim()){e=c.trim();break}}}if(console.log("Claude query extracted:",e),!e.trim()){console.log("No query text found for Claude");return}const o=document.querySelector('[id*="sm-claude-input-bar-element"]');if(!o){console.warn("Claude icon element not found, cannot update feedback");return}I("Searching memories...",o);const s=new Promise((a,l)=>setTimeout(()=>l(new Error("Memory search timeout")),w.API_REQUEST_TIMEOUT)),i=await Promise.race([m.runtime.sendMessage({action:h.GET_RELATED_MEMORIES,data:e,actionSource:r}),s]);if(console.log("Claude memories response:",i),i?.success&&i?.data){const a=document.querySelector('div[contenteditable="true"]');a?(a.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${i.data}</div>`,console.log("Text element dataset:",a.dataset.supermemories),o.dataset.memoriesData=i.data,I("Included Memories",o)):(console.warn("Claude input area not found after successful memory fetch"),I("Memories found",o))}else console.warn("No memories found or API response invalid for Claude"),I("No memories found",o)}catch(e){console.error("Error getting related memories for Claude:",e);try{const t=document.querySelector('[id*="sm-claude-input-bar-element"]');t&&I("Error fetching memories",t)}catch(t){console.error("Failed to update Claude error feedback:",t)}}}function I(r,e,t=0){e.dataset.originalHtml||(e.dataset.originalHtml=e.innerHTML);const n=document.createElement("div");if(n.style.cssText=`
		display: flex; 
		align-items: center; 
		gap: 6px; 
		padding: 6px 8px; 
		background: #513EA9; 
		border-radius: 6px; 
		color: white; 
		font-size: 12px; 
		font-weight: 500;
		cursor: ${r==="Included Memories"?"pointer":"default"};
		position: relative;
	`,n.innerHTML=`
		<span>✓</span>
		<span>${r}</span>
	`,r==="Included Memories"&&e.dataset.memoriesData){const o=document.createElement("div");o.style.cssText=`
			position: fixed;
			bottom: 80px;
			left: 50%;
			transform: translateX(-50%);
			background: #1a1a1a;
			color: white;
			padding: 0;
			border-radius: 12px;
			font-size: 13px;
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
			max-width: 500px;
			max-height: 400px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			z-index: 999999;
			display: none;
			border: 1px solid #333;
		`;const s=document.createElement("div");s.style.cssText=`
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px;
			border-bottom: 1px solid #333;
			opacity: 0.8;
		`,s.innerHTML=`
			<span style="font-weight: 600; color: #fff;">Included Memories</span>
		`;const i=document.createElement("div");i.style.cssText=`
			padding: 0;
			max-height: 300px;
			overflow-y: auto;
		`;const a=e.dataset.memoriesData||"";console.log("Memories text:",a);const l=a.split(/[,\n]/).map(c=>c.trim()).filter(c=>c.length>0&&c!==",");console.log("Individual memories:",l),l.forEach((c,g)=>{const p=document.createElement("div");p.style.cssText=`
				display: flex;
				align-items: center;
				gap: 6px;
				padding: 10px;
				font-size: 13px;
				line-height: 1.4;
			`;const f=document.createElement("div");f.style.cssText=`
				flex: 1;
				color: #e5e5e5;
			`,f.textContent=c.trim();const d=document.createElement("button");d.style.cssText=`
				background: transparent;
				color: #9ca3af;
				border: none;
				padding: 4px;
				border-radius: 4px;
				cursor: pointer;
				flex-shrink: 0;
				height: fit-content;
				display: flex;
				align-items: center;
				justify-content: center;
			`,d.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',d.dataset.memoryIndex=g.toString(),d.addEventListener("mouseenter",()=>{d.style.color="#ef4444"}),d.addEventListener("mouseleave",()=>{d.style.color="#9ca3af"}),p.appendChild(f),p.appendChild(d),i.appendChild(p)}),o.appendChild(s),o.appendChild(i),document.body.appendChild(o),n.addEventListener("mouseenter",()=>{const c=n.querySelector("span:last-child");c&&(c.textContent="Click to see memories")}),n.addEventListener("mouseleave",()=>{const c=n.querySelector("span:last-child");c&&(c.textContent="Included Memories")}),n.addEventListener("click",c=>{c.stopPropagation(),o.style.display="block"}),document.addEventListener("click",c=>{o.contains(c.target)||(o.style.display="none")}),i.querySelectorAll("button[data-memory-index]").forEach(c=>{const g=c;g.addEventListener("click",()=>{const p=Number.parseInt(g.dataset.memoryIndex||"0",10),f=g.parentElement;f&&i.removeChild(f);const d=(e.dataset.memoriesData||"").split(/[,\n]/).map(T=>T.trim()).filter(T=>T.length>0&&T!==",");d.splice(p,1);const v=d.join(" ,");e.dataset.memoriesData=v;const x=document.querySelector('div[contenteditable="true"]');x&&(x.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${v}</div>`),i.querySelectorAll("button[data-memory-index]").forEach((T,O)=>{const N=T;N.dataset.memoryIndex=O.toString()}),d.length<=1&&(x?.dataset.supermemories&&(delete x.dataset.supermemories,delete e.dataset.memoriesData,e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml),o.style.display="none",document.body.contains(o)&&document.body.removeChild(o))})}),setTimeout(()=>{document.body.contains(o)&&document.body.removeChild(o)},3e5)}e.innerHTML="",e.appendChild(n),t>0&&setTimeout(()=>{e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml},t)}function be(){if(document.body.hasAttribute("data-claude-prompt-capture-setup"))return;document.body.setAttribute("data-claude-prompt-capture-setup","true");const r=async e=>{let t="";const n=document.querySelector('div[contenteditable="true"]');if(n&&(t=n.textContent||n.innerText||""),!t){const i=document.querySelector("textarea");i&&(t=i.value||"")}const o=n?.dataset.supermemories;if(o&&n&&!t.includes("Kortix memories of user")&&(n.innerHTML=`${n.innerHTML} ${o}`,t=n.textContent||n.innerText||""),t.trim()){console.log(`Claude prompt submitted via ${e}:`,t);try{await m.runtime.sendMessage({action:h.CAPTURE_PROMPT,data:{prompt:t,platform:"claude",source:e}})}catch(i){console.error("Error sending Claude prompt to background:",i)}}document.querySelectorAll('[id*="sm-claude-input-bar-element"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),n?.dataset.supermemories&&delete n.dataset.supermemories};document.addEventListener("click",async e=>{const t=e.target;(t.closest("button.inline-flex.items-center.justify-center.relative.shrink-0.can-focus.select-none")||t.closest('button[class*="bg-accent-main-000"]')||t.closest('button[class*="rounded-lg"]'))&&await r("button click")},!0),document.addEventListener("keydown",async e=>{const t=e.target;(t.matches('div[contenteditable="true"]')||t.matches(".ProseMirror")||t.matches("textarea")||t.closest(".ProseMirror"))&&e.key==="Enter"&&!e.shiftKey&&await r("Enter key")},!0)}async function j(){if(!((await chrome.storage.local.get([b.AUTO_SEARCH_ENABLED]))[b.AUTO_SEARCH_ENABLED]??!1))return;const t=document.querySelector('div[contenteditable="true"]');if(!t||t.hasAttribute("data-kortix-auto-fetch"))return;t.setAttribute("data-kortix-auto-fetch","true");const n=()=>{z&&clearTimeout(z),z=setTimeout(async()=>{const o=t.textContent?.trim()||"";o.length>2?await ne("claude_chat_memories_auto_searched"):o.length===0&&(document.querySelectorAll('[id*="sm-claude-input-bar-element"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t.dataset.supermemories&&delete t.dataset.supermemories)},w.AUTO_SEARCH_DEBOUNCE_DELAY)};t.addEventListener("input",n)}const ve=["youtube.com","www.youtube.com","youtu.be","m.youtube.com","music.youtube.com"];function we(r){try{const e=new URL(r).hostname;return ve.some(t=>e===t||e.endsWith(`.${t}`))}catch{return!1}}async function W(){try{u.showToast("loading");const r=window.getSelection()?.toString()||"",e=window.location.href,t=document.title,n=we(e),o=n?"":document.documentElement.outerHTML,s=await m.runtime.sendMessage({action:h.SAVE_MEMORY,data:{html:o,highlightedText:r,url:e,title:t,isLink:n},actionSource:"context_menu"});console.log("Response from enxtension:",s),s.success?u.showToast("success"):u.showToast("error")}catch(r){console.error("Error saving memory:",r),u.showToast("error")}}function ke(){document.addEventListener("keydown",async r=>{(r.ctrlKey||r.metaKey)&&r.shiftKey&&r.key==="m"&&(r.preventDefault(),await W())})}function Se(){window.addEventListener("message",r=>{if(!r.data||typeof r.data!="object")return;const e=r.data.token,t=r.data.refreshToken,n=r.data.userData;if(e&&n){if(!E.KORTIX.includes(window.location.hostname))return;chrome.storage.local.set({[b.BEARER_TOKEN]:e,[b.USER_DATA]:n,...t&&{[b.REFRESH_TOKEN]:t}},()=>{})}})}let V=null,H=null,_=null,L=null;function re(){u.isOnDomain(E.T3)&&(document.body.hasAttribute("data-t3-initialized")||(setTimeout(()=>{console.log("Adding kortix icon to T3 input"),Y(),Q()},2e3),Ce(),Me(),document.body.setAttribute("data-t3-initialized","true")))}function Me(){H&&H.disconnect(),_&&clearInterval(_),L&&(clearTimeout(L),L=null);let r=window.location.href;const e=()=>{window.location.href!==r&&(r=window.location.href,console.log("T3 route changed, re-adding kortix icon"),setTimeout(()=>{Y(),Q()},1e3))};_=setInterval(e,2e3),H=new MutationObserver(t=>{if(L)return;let n=!1;t.forEach(o=>{o.type==="childList"&&o.addedNodes.length>0&&o.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){const i=s;(i.querySelector?.("textarea")||i.querySelector?.('div[contenteditable="true"]')||i.matches?.("textarea")||i.matches?.('div[contenteditable="true"]'))&&(n=!0)}})}),n&&(L=setTimeout(()=>{try{L=null,Y(),Q()}catch(o){console.error("Error in T3 observer callback:",o)}},300))});try{H.observe(document.body,{childList:!0,subtree:!0})}catch(t){console.error("Failed to set up T3 route observer:",t),_&&clearInterval(_),_=setInterval(e,1e3)}}function Y(){document.querySelectorAll(".flex.min-w-0.items-center.gap-2.overflow-hidden").forEach(e=>{if(e.hasAttribute("data-kortix-icon-added"))return;if(e.querySelector(`#${y.T3_INPUT_BAR_ELEMENT}`)){e.setAttribute("data-kortix-icon-added","true");return}const n=ge(async()=>{await ie("t3_chat_memories_searched")});n.id=`${y.T3_INPUT_BAR_ELEMENT}-${Date.now()}-${Math.random().toString(36).substring(2,11)}`,e.setAttribute("data-kortix-icon-added","true"),e.insertBefore(n,e.firstChild)})}async function ie(r){try{let e="";const t=document.querySelector('[data-kortix-icon-added="true"]');if(t?.parentElement?.parentElement?.previousElementSibling&&(e=t.parentElement.parentElement.previousElementSibling.querySelector("textarea")?.value||""),!e.trim()){const a=document.querySelector('div[contenteditable="true"]');e=a?.innerText||a?.textContent||""}if(!e.trim()){const a=document.querySelectorAll("textarea");for(const l of a){const c=l.value;if(c?.trim()){e=c.trim();break}}}if(console.log("T3 query extracted:",e),!e.trim()){console.log("No query text found for T3");return}const o=document.querySelector('[id*="sm-t3-input-bar-element"]');if(!o){console.warn("T3 icon element not found, cannot update feedback");return}R("Searching memories...",o);const s=new Promise((a,l)=>setTimeout(()=>l(new Error("Memory search timeout")),w.API_REQUEST_TIMEOUT)),i=await Promise.race([m.runtime.sendMessage({action:h.GET_RELATED_MEMORIES,data:e,actionSource:r}),s]);if(console.log("T3 memories response:",i),i?.success&&i?.data){let a=null;const l=document.querySelector('[data-kortix-icon-added="true"]');l?.parentElement?.parentElement?.previousElementSibling&&(a=l.parentElement.parentElement.previousElementSibling.querySelector("textarea")),a||(a=document.querySelector('div[contenteditable="true"]')),a?(a.tagName==="TEXTAREA"?a.dataset.supermemories=`<br>Kortix memories of user (only for the reference): ${i.data}</br>`:a.dataset.supermemories=`<br>Kortix memories of user (only for the reference): ${i.data}</br>`,o.dataset.memoriesData=i.data,R("Included Memories",o)):(console.warn("T3 input area not found after successful memory fetch"),R("Memories found",o))}else console.warn("No memories found or API response invalid for T3"),R("No memories found",o)}catch(e){console.error("Error getting related memories for T3:",e);try{const t=document.querySelector('[id*="sm-t3-input-bar-element"]');t&&R("Error fetching memories",t)}catch(t){console.error("Failed to update T3 error feedback:",t)}}}function R(r,e,t=0){e.dataset.originalHtml||(e.dataset.originalHtml=e.innerHTML);const n=document.createElement("div");if(n.style.cssText=`
		display: flex; 
		align-items: center; 
		gap: 6px; 
		padding: 6px 8px; 
		background: #513EA9; 
		border-radius: 6px; 
		color: white; 
		font-size: 12px; 
		font-weight: 500;
		cursor: ${r==="Included Memories"?"pointer":"default"};
		position: relative;
	`,n.innerHTML=`
		<span>✓</span>
		<span>${r}</span>
	`,r==="Included Memories"&&e.dataset.memoriesData){const o=document.createElement("div");o.style.cssText=`
			position: fixed;
			bottom: 80px;
			left: 50%;
			transform: translateX(-50%);
			background: #1a1a1a;
			color: white;
			padding: 0;
			border-radius: 12px;
			font-size: 13px;
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
			max-width: 500px;
			max-height: 400px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			z-index: 999999;
			display: none;
			border: 1px solid #333;
		`;const s=document.createElement("div");s.style.cssText=`
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px;
			border-bottom: 1px solid #333;
			opacity: 0.8;
		`,s.innerHTML=`
			<span style="font-weight: 600; color: #fff;">Included Memories</span>
		`;const i=document.createElement("div");i.style.cssText=`
			padding: 0;
			max-height: 300px;
			overflow-y: auto;
		`;const a=e.dataset.memoriesData||"";console.log("Memories text:",a);const l=a.split(/[,\n]/).map(c=>c.trim()).filter(c=>c.length>0&&c!==",");console.log("Individual memories:",l),l.forEach((c,g)=>{const p=document.createElement("div");p.style.cssText=`
				display: flex;
				align-items: center;
				gap: 6px;
				padding: 10px;
				font-size: 13px;
				line-height: 1.4;
			`;const f=document.createElement("div");f.style.cssText=`
				flex: 1;
				color: #e5e5e5;
			`,f.textContent=c.trim();const d=document.createElement("button");d.style.cssText=`
				background: transparent;
				color: #9ca3af;
				border: none;
				padding: 4px;
				border-radius: 4px;
				cursor: pointer;
				flex-shrink: 0;
				height: fit-content;
				display: flex;
				align-items: center;
				justify-content: center;
			`,d.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',d.dataset.memoryIndex=g.toString(),d.addEventListener("mouseenter",()=>{d.style.color="#ef4444"}),d.addEventListener("mouseleave",()=>{d.style.color="#9ca3af"}),p.appendChild(f),p.appendChild(d),i.appendChild(p)}),o.appendChild(s),o.appendChild(i),document.body.appendChild(o),n.addEventListener("mouseenter",()=>{const c=n.querySelector("span:last-child");c&&(c.textContent="Click to see memories")}),n.addEventListener("mouseleave",()=>{const c=n.querySelector("span:last-child");c&&(c.textContent="Included Memories")}),n.addEventListener("click",c=>{c.stopPropagation(),o.style.display="block"}),document.addEventListener("click",c=>{o.contains(c.target)||(o.style.display="none")}),i.querySelectorAll("button[data-memory-index]").forEach(c=>{const g=c;g.addEventListener("click",()=>{const p=Number.parseInt(g.dataset.memoryIndex||"0",10),f=g.parentElement;f&&i.removeChild(f);const d=(e.dataset.memoriesData||"").split(/[,\n]/).map(T=>T.trim()).filter(T=>T.length>0&&T!==",");d.splice(p,1);const v=d.join(" ,");e.dataset.memoriesData=v;const x=document.querySelector("textarea")||document.querySelector('div[contenteditable="true"]');x&&(x.dataset.supermemories=`<div>Kortix memories of user (only for the reference): ${v}</div>`),i.querySelectorAll("button[data-memory-index]").forEach((T,O)=>{const N=T;N.dataset.memoryIndex=O.toString()}),d.length<=1&&(x?.dataset.supermemories&&(delete x.dataset.supermemories,delete e.dataset.memoriesData,e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml),o.style.display="none",document.body.contains(o)&&document.body.removeChild(o))})}),setTimeout(()=>{document.body.contains(o)&&document.body.removeChild(o)},3e5)}e.innerHTML="",e.appendChild(n),t>0&&setTimeout(()=>{e.innerHTML=e.dataset.originalHtml||"",delete e.dataset.originalHtml},t)}function Ce(){if(document.body.hasAttribute("data-t3-prompt-capture-setup"))return;document.body.setAttribute("data-t3-prompt-capture-setup","true");const r=async e=>{let t="";const n=document.querySelector("textarea");if(n&&(t=n.value||""),!t){const a=document.querySelector('div[contenteditable="true"]');a&&(t=a.textContent||a.innerText||"")}const o=n||document.querySelector('div[contenteditable="true"]'),s=o?.dataset.supermemories;if(s&&o&&!t.includes("Kortix memories of user")&&(o.tagName==="TEXTAREA"?(o.value=`${t} ${s}`,t=o.value):(o.innerHTML=`${o.innerHTML} ${s}`,t=o.textContent||o.innerText||"")),t.trim()){console.log(`T3 prompt submitted via ${e}:`,t);try{await m.runtime.sendMessage({action:h.CAPTURE_PROMPT,data:{prompt:t,platform:"t3",source:e}})}catch(a){console.error("Error sending T3 prompt to background:",a)}}document.querySelectorAll('[id*="sm-t3-input-bar-element"]').forEach(a=>{const l=a;l.dataset.originalHtml&&(l.innerHTML=l.dataset.originalHtml,delete l.dataset.originalHtml,delete l.dataset.memoriesData)}),o?.dataset.supermemories&&delete o.dataset.supermemories};document.addEventListener("click",async e=>{const t=e.target;(t.closest("button.focus-visible\\:ring-ring")||t.closest('button[class*="bg-[rgb(162,59,103)]"]')||t.closest('button[class*="rounded-lg"]'))&&await r("button click")},!0),document.addEventListener("keydown",async e=>{const t=e.target;if((t.matches("textarea")||t.matches('div[contenteditable="true"]'))&&e.key==="Enter"&&!e.shiftKey)if(t.matches("textarea")){const n=t.value||"";if(n.trim()){console.log("T3 prompt submitted via Enter key:",n);try{await m.runtime.sendMessage({action:h.CAPTURE_PROMPT,data:{prompt:n,platform:"t3",source:"Enter key"},actionSource:"t3"})}catch(o){console.error("Error sending T3 textarea prompt to background:",o)}}}else await r("Enter key")},!0)}async function Q(){if(!((await chrome.storage.local.get([b.AUTO_SEARCH_ENABLED]))[b.AUTO_SEARCH_ENABLED]??!1))return;const t=document.querySelector("textarea")||document.querySelector('div[contenteditable="true"]');if(!t||t.hasAttribute("data-kortix-auto-fetch"))return;t.setAttribute("data-kortix-auto-fetch","true");const n=()=>{V&&clearTimeout(V),V=setTimeout(async()=>{let o="";t.tagName==="TEXTAREA"?o=t.value?.trim()||"":o=t.textContent?.trim()||"",o.length>2?await ie("t3_chat_memories_auto_searched"):o.length===0&&(document.querySelectorAll('[id*="sm-t3-input-bar-element"]').forEach(i=>{const a=i;a.dataset.originalHtml&&(a.innerHTML=a.dataset.originalHtml,delete a.dataset.originalHtml,delete a.dataset.memoriesData)}),t.dataset.supermemories&&delete t.dataset.supermemories)},w.AUTO_SEARCH_DEBOUNCE_DELAY)};t.addEventListener("input",n)}function _e(){u.isOnDomain(E.TWITTER)&&(window.location.pathname==="/i/bookmarks"?setTimeout(()=>{ae()},2e3):u.elementExists(y.TWITTER_IMPORT_BUTTON)&&u.removeElement(y.TWITTER_IMPORT_BUTTON))}function ae(){if(window.location.pathname!=="/i/bookmarks"||u.elementExists(y.TWITTER_IMPORT_BUTTON))return;const r=me(async()=>{try{await m.runtime.sendMessage({type:h.BATCH_IMPORT_ALL})}catch(e){console.error("Error starting import:",e)}});document.body.appendChild(r)}function se(r){const e=document.getElementById(y.TWITTER_IMPORT_BUTTON);if(!e)return;const t=m.runtime.getURL("/icon-16.png");if(r.type===h.IMPORT_UPDATE&&(e.innerHTML=`
			<img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
			<span style="font-weight: 500; font-size: 14px;">${r.importedMessage}</span>
		`,e.style.cursor="default"),r.type===h.IMPORT_DONE){const n=r.totalImported??0,o=r.totalSkipped??0;let s,i;n===0&&o>0?(s=`All ${o} tweets were already saved`,i="#d97706"):n>0&&o>0?(s=`✓ ${n} new tweets imported, ${o} already saved`,i="#059669"):(s=`✓ ${n} new tweets imported`,i="#059669"),e.innerHTML=`
			<img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
			<span style="font-weight: 500; font-size: 14px; color: ${i};">${s}</span>
		`,setTimeout(()=>{e.innerHTML=`
				<img src="${t}" width="20" height="20" alt="Save to Memory" style="border-radius: 4px;" />
				<span style="font-weight: 500; font-size: 14px;">Import Bookmarks</span>
			`,e.style.cursor="pointer"},5e3)}}function Le(){u.isOnDomain(E.TWITTER)&&(window.location.pathname==="/i/bookmarks"?ae():u.elementExists(y.TWITTER_IMPORT_BUTTON)&&u.removeElement(y.TWITTER_IMPORT_BUTTON))}const Ae={matches:["<all_urls>"],main(){const r=async s=>{const i=`${Date.now()}-${Math.random().toString(36).slice(2)}`;return await new Promise(a=>{const l="kortix-grid-response",c="kortix-grid-request",g=d=>{const v=d.detail;!v||v.requestId!==i||(p(),a({active:!!v.active}))},p=()=>{document.removeEventListener(l,g),window.clearTimeout(f)},f=window.setTimeout(()=>{p(),a({active:"twcStarted"in document.body.dataset})},1200);document.addEventListener(l,g),document.dispatchEvent(new CustomEvent(c,{detail:{requestId:i,command:s}}))})};window.addEventListener("message",async s=>{if(s.data?.type==="KORTIX_NLM_START_CAPTURE")try{const i=await m.runtime.sendMessage({type:h.NLM_START_CAPTURE});window.postMessage({type:i?.success?"KORTIX_NLM_COOKIES":"KORTIX_NLM_ERROR",data:i},"*")}catch(i){window.postMessage({type:"KORTIX_NLM_ERROR",data:{success:!1,error:i instanceof Error?i.message:String(i)}},"*")}}),m.runtime.onMessage.addListener((s,i,a)=>{if(s.action===h.SHOW_TOAST)u.showToast(s.state);else{if(s.action===h.SAVE_MEMORY)return W().then(()=>a({success:!0})).catch(()=>a({success:!1})),!0;if(s.action===h.TOGGLE_X_GRID||s.action===h.GET_X_GRID_STATE){if(!u.isOnDomain(E.TWITTER)){a({active:!1});return}const l=s.action===h.TOGGLE_X_GRID?"toggle":"state";return r(l).then(a).catch(c=>{console.error("Failed to bridge Twitter grid action:",c),a({active:!1})}),!0}else(s.type===h.IMPORT_UPDATE||s.type===h.IMPORT_DONE)&&se(s)}}),ke(),Se();const e=()=>{new MutationObserver(()=>{u.isOnDomain(E.CHATGPT)&&ee(),u.isOnDomain(E.CLAUDE)&&oe(),u.isOnDomain(E.T3)&&re(),u.isOnDomain(E.TWITTER)&&Le()}).observe(document.body,{childList:!0,subtree:!0})};ee(),oe(),re(),_e();const t=u.isOnDomain(E.KORTIX)||u.isOnDomain(E.TWITTER),n=()=>{if(t||u.elementExists(y.SAVE_PAGE_BUTTON))return;const s=pe(()=>W());document.body.appendChild(s)},o=()=>{u.removeElement(y.SAVE_PAGE_BUTTON)};chrome.storage.local.get(b.SAVE_PAGE_BUTTON_ENABLED).then(s=>{s[b.SAVE_PAGE_BUTTON_ENABLED]&&n()}),chrome.storage.onChanged.addListener((s,i)=>{if(i!=="local")return;const a=s[b.SAVE_PAGE_BUTTON_ENABLED];a&&(a.newValue?n():o())}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",e):e()}};function B(r,...e){}const Ie={debug:(...r)=>B(console.debug,...r),log:(...r)=>B(console.log,...r),warn:(...r)=>B(console.warn,...r),error:(...r)=>B(console.error,...r)};class J extends Event{constructor(e,t){super(J.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=t}static EVENT_NAME=Z("wxt:locationchange")}function Z(r){return`${m?.runtime?.id}:content:${r}`}function Re(r){let e,t;return{run(){e==null&&(t=new URL(location.href),e=r.setInterval(()=>{let n=new URL(location.href);n.href!==t.href&&(window.dispatchEvent(new J(n,t)),t=n)},1e3))}}}class q{constructor(e,t){this.contentScriptName=e,this.options=t,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=Z("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=Re(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return m.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,t){const n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){const n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){const t=requestAnimationFrame((...n)=>{this.isValid&&e(...n)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){const n=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,o){t==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith("wxt:")?Z(t):t,n,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Ie.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:q.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){const t=e.data?.type===q.SCRIPT_STARTED_MESSAGE_TYPE,n=e.data?.contentScriptName===this.contentScriptName,o=!this.receivedMessageIds.has(e.data?.messageId);return t&&n&&o}listenForNewerScripts(e){let t=!0;const n=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const s=t;if(t=!1,s&&e?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}}function Ue(){}function $(r,...e){}const Oe={debug:(...r)=>$(console.debug,...r),log:(...r)=>$(console.log,...r),warn:(...r)=>$(console.warn,...r),error:(...r)=>$(console.error,...r)};return(async()=>{try{const{main:r,...e}=Ae,t=new q("content",e);return await r(t)}catch(r){throw Oe.error('The content script "content" crashed on startup!',r),r}})()})();
content;